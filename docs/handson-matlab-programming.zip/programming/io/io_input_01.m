v1 = input('give number')
v2 = v1 * 10
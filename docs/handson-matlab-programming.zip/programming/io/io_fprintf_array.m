%
% example taken from http://blog.developpez.com/dut/
%

M = [1 2 ; 3 4 ; 5 6];

fid = fopen('test.txt', 'wt');
fprintf(fid, '%d %d\n', M);
fclose(fid);
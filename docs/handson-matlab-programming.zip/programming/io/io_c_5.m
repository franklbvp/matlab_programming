%
% io_c_5
%

%
% open file
%
fid=fopen('data.txt', 'r');
if(fid==-1)
   error('error reading file');
end

title = fgetl(fid); % get first line of file

k=0; % initialise counter
while ~feof(fid) % � is the negation operator in matlab
   k=k+1; 
   line = fgetl(fid); % get next line from file
   tab(k,:) = str2num(line); % convert the line into a vector, and record in a table
end
fclose(fid);
%
% get financial data from the internet
%
% surf to http://finance.yahoo.com/
%
% choose a company
% click historical prizes
% download to a spreadsheet
%
% figure out the structure of the url
%
clear
clc
%
% urlread: the contents is saved as a single string  
%
urlstring = sprintf('%s%s', ...
   'http://ichart.finance.yahoo.com/table.csv?s=%5EGDAXI&a=08&b=1&c=2010&d=08&e=30&f=2013&g=w&ignore=.csv');
s = urlread(urlstring);

% 
% urlwrite: save the data to a file
%
if exist('financial_data.csv') 
    delete('financial_data.csv');
end
urlwrite(urlstring, 'financial_data.csv');
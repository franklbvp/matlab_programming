filename = 'outputfile.dat';                 % Initialisation.
rows = 4;
cols = 3;

m = rand(rows, cols);                        % Generate random numbers.

[fid, message] = fopen(filename, 'wt');      % Open a text file for
                                             % writing.
if fid == -1
    fprintf('File %s could not be opened \n', filename);
    error(message);  
end

fprintf(fid, 'This is a %dx%d matrix of random numbers.\n\n', rows, cols);

for r = 1 : rows

    fprintf(fid, 'Row %d:  ', r);            % Write the row number
                                             % into the file.
    for c = 1 : cols
        fprintf(fid, '   %8.4f', m(r,c));    % Write each column of
    end                                      % the row.

    fprintf(fid, '\n');                      % Write a newline before
                                             % starting the next row.
end

fclose(fid);                                 % Close the file.
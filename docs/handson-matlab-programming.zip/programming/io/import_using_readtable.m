%% Using the readvars function
% creates  _*separate column variables*_ by reading _*column-oriented data*_ 
% from a file
% 
% suited for mixed data and spreadsheets, the elements of a column are of the 
% same data type.
% 
% 
%% readvars without extra options
% 
% 
% read a comma separated file
% 
% Ignore the columns using a tilde (|~|).

opts_v = detectImportOptions('csvlist_65.dat')
preview('csvlist_65.dat', opts_v)

[a_1v1, a_1v2, a_1v3, a_1v4, a_1v5, a_1v6] = readvars('csvlist_65.dat')

[a_1v1r, a_1v2r, ~, a_1v4r] = readvars('csvlist_65.dat') % select only a view columns 
%% 
% read a comma separated file, with missing values
% 
% missing values are noted as such

[a_2v1, ~, a_2v3] = readvars('csvlist_65_empty.dat')
%% 
% read a tab separated file, a mixture of numerical and alphanumeric data
% 
% check the data type of the different variables

[a_3v1, ~, a_3v3, ~, ~, a_3v6] = readvars('81_nohead.dat')
%% 
% 
%% 
% read a file containing blanc lines and some missing values
% 
% readvars will crash on this type of file, a strict column approach is expected

opts_v = detectImportOptions('ImportMixedFile_01.txt')
preview('ImportMixedFile_01.txt', opts_v)

[a_4v1, a_4v2, a_4v3] = readvars('ImportMixedFile_01.txt')
%% 
% 
%% 
% read a xlsx file
% 
% the first sheet is imported

opts_v = detectImportOptions('airlinesmall_subset.xlsx')
preview('airlinesmall_subset.xlsx', opts_v)

a_5 = readvars('airlinesmall_subset.xlsx')
%% readvars using import options
% 
% 
% use the detectImportOptions function, use this object to get a preview

opts_1 = detectImportOptions('csvlist_65.dat');
preview('csvlist_65.dat',opts_1)
a_1o = readvars('csvlist_65.dat', opts_1)
%% 
% 
% 
% change the options to guide the import
%% 
% * import only columns selected columns
% * import a range of rows

opts_1 = detectImportOptions('csvlist_65.dat');
opts_1.VariableNames  % show the list of the variables (columns)
getvaropts(opts_1, "Var3")
opts_1.VariableNames = {'Variab1', 'Variab2', 'Variab3', 'Variab4', 'Variab5', 'Variab6'}
opts_1.SelectedVariableNames = {'Variab1', 'Variab2', 'Variab5'}
[a_1o1, a_1o2, a_1o3] = readvars('csvlist_65.dat', opts_1)
opts_1.DataLines = [2 4]
a_1o2 = readvars('csvlist_65.dat', opts_1)
%% 
% 
%% 
% importing a mixed file with the options object.
% 
% importing the same file with the opts object will now work!
% 
% 

opts = detectImportOptions('ImportMixedFile_01.txt');
preview('ImportMixedFile_01.txt',opts)
opts % show content of opts object
opts.VariableTypes % check the types
[a_opts1, a_opts2, a_opts3, a_opts4, a_opts5, a_opts6]  = readvars('ImportMixedFile_01.txt', opts)
%% 
% 
%% 
% 
% 
% use the detectImportOptions function on an Excel file, this will return another 
% import object, wth specific information
%% 
% * preview the file (by default 8 lines are shown)
%% 
% The spreadsheet file |airlinesmall_subset.xlsx| contains data in multiple 
% worksheets for years between 1996 and 2008.  Each worksheet has data for a given 
% year. Preview the data from file |airlinesmall_subset.xlsx|. The |preview| function 
% shows data from the from the first worksheet by default. The first eight variables 
% in the file contain numerical data.

opts_x = detectImportOptions('airlinesmall_subset.xlsx')
preview('airlinesmall_subset.xlsx',opts_x)
%% 
% 
% 
% specific properties are:
%% 
% * Sheet
% * DataRange
% * VariableNamesRange
% * RowNamesRange
%% 
% use als xlsfinfo, to get more information on the excel file

opts_x = detectImportOptions('airlinesmall_subset.xlsx')
preview('airlinesmall_subset.xlsx',opts_x)
opts_x.Sheet = '2007'
opts_x.SelectedVariableNames = 'ArrDelay'

a_x_opts_delay = readvars('airlinesmall_subset.xlsx', opts_x)
plot(a_x_opts_delay)
%% 
% 
%% readvars using option value pairs
% 
% 
% similar to setting the parameters in options object

[a_x_vpa, a_x_vpb, a_x_vpc, ~, ~, a_x_vpf] = readvars('airlinesmall_subset.xlsx','Sheet','2008','Range','A2:K11')
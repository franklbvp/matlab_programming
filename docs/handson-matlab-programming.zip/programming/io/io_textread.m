%
% io_textread.m
% read data via textread
% read data from tabel.dat
%
[vrnaam, fmnaam, bloed, index, leeftijd, antw] = textread('tabel.dat', '%s  %s  %s  %f  %d %s')
%
vrnaam
leeftijd
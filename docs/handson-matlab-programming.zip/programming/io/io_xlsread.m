%
% demo reading from:
%   demo.xls (numbers only)
%   demo_mix.xls  (sheet 1
%

% This will tell you (i) if the file can be read properly, and (ii) what
% the names of the sheets are.
[d_info, d_sheet] = xlsfinfo('demo.xls')
%
a = xlsread('demo.xls', d_sheet{1});
a

b = xlsread('demo.xls', d_sheet{2});
b

% reading an excel sheet containing numerical and text data
aa = xlsread('demo_mix.xls', 'first');
%
% nummbers, text are read separately
%
[aaa t raw]=  xlsread('demo_mix.xls', 'first');

%
% work interactively
%
% intinp = xlsread('demo_mix.xls', -1);

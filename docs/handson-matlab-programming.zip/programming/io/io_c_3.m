%
% read mat-file
%
clear

load temp1.mat               	% temp1.mat contains variable c with data 

plot(c(:,1),c(:,2))

%
% importdata demo - read a file 81.dat
%                   a mixed (text + numerics) data file
%
  
clear
clc

datm = importdata('81.dat');

datmn = importdata('81_nohead.dat',' ');


A = importdata('abandon_data.dat', ',')

dat = importdata('data2.CSV');
%
% plot the data
%
 plot (dat(:,1), dat(:,2));

a = input('give a number:')
b = a+1
disp(a)
disp(b)
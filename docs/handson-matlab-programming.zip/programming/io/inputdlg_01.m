prompt = {'Enter matrix size:','Enter colormap name:'};
dlgtitle = 'Input';
dims = [1 35];
definput = {'20','hsv'};
answer = inputdlg(prompt,dlgtitle,dims,definput)
%
% fprintf example
%
% based on http://web.cecs.pdx.edu/~gerry/class/ME352/notes/quick/pdf/demofprintf.pdf
%

n = 5;
x = linspace(-pi,pi,n);
y = x/1e6;
z = x*1e6;


fprintf('\nSimple fprintf statement\n');
for j=1:length(x)
%    fprintf('%d %f %f %f \n',j,x(j),y(j),z(j));
%    fprintf('%d %12.3e %12.4e %12.5e \n',j,x(j),y(j),z(j));
    fprintf('%d %g %g %g \n',j,x(j),y(j),z(j));
end

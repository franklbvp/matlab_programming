%
% example of interactive input / output
%
% conversion degree - radian
%
degreeStart = input('enter the degrees to start from: ');
degreeStop = input('enter the degrees to stop: ');
increm = input('increment: ');


degree = degreeStart:increm:degreeStop;
radian = degree * pi / 180;
table = [degree; radian];

disp('Conversiontable degrees to radian');
fprintf(' %4.2f   %6.4f  \n',table)
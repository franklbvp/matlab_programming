%
%  io_formats : a quick look at formats 
%
%   The "fprintf" and "sprintf" commands (and some other read/write
%   commands) use templates called "formats" to control the form of 
%   the result.  A format template is a character string (vector).
%   Basically, the template itself appears in the output, for example --

fprintf('Hello world \n')

%   Numbers can be inserted in the text.  "%f is a  code for insert-
%   ing a number. 

fprintf('First number = %f,  next number = %f \n', 11, 2/3)

%   The number of places after the decimal point can be
%   controlled:  "%.2f" produces two digits after the point.

fprintf('First number = %.2f,  next number = %.9f \n', 1/3, 1/3)

%    The special sequence, "\n", starts a new line.
fprintf(' Pi to  2 places %.2f \n Pi to 12 places %.12f \n', pi,pi)  
 
%    The "%e" code displays numbers in scientific notation:

fprintf(' Pi = %e   Million = %e   1/700 = %e \n', pi, 1E6, 1/700)

%    For more (or fewer) places after the decimal point use   
%    -- percent sign,  decimal point, number, "e" .

X=9.12345678901234E-8;          % Now print X twice.
fprintf('   2 places %.2e;   14 places %.14e \n', X,X)

%    The "%s" code inserts text in the template.

fileName = 'home/assignments/a1.txt';
fprintf('My first assignment is in the file, "%s" \n', fileName)

fprintf('%5c','matlab') % digit string specifying the minimum number of digits to be printed

fprintf('\n')

fprintf('%c','matlab')

fprintf('\n')

fprintf('%5g',10)

fprintf('\n')

fprintf('%10.4f',123.456)   %A digit string including a period (.) 
                            %specifying the number of digits to be printed 
                            %to the right of the decimal point.

fprintf('\n')

fprintf('%10s', 'fred')

fprintf('\n')

fprintf('%d',100.35)

fprintf('\n')

fprintf('%d',100)

fprintf('\n')

fprintf('%i',100.67)


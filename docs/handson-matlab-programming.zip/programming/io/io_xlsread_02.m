%
% demo file reading and writing xls
%
% read student data from Excel file
[numbers, text] = xlsread('class.xls');

% get rid of headers
names = text(2:end,1);
exams = numbers;

% find mean of each row (2nd dimension) of exam scores
averages = mean(exams,2);

% put results in cell array for saving
for k = 1:1:length(names)
    results{k,1} = names{k};
    results{k,2} = exams(k,1);
    results{k,3} = exams(k,2);
    results{k,4} = exams(k,3);
    results{k,5} = averages(k);
end
xlswrite('classmod.xls',results);
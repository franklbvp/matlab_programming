%
% read from a file with C-like commands
%

fid=fopen('temp1.txt','r');	    % open temp1.txt for "read text"
                                % fid is assigned to the file
a=fscanf(fid,'%f %f',[2,101])'	% read all data into "a" (two rows by 101 columns, then transposed) 

fclose(fid)                 	% close file

plot(a(:,1),a(:,2))            	% plot col 2 (y) versus col 1 (x)

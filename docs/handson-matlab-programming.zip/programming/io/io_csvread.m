%
% csvread demo - read a file csvlist.csv
%
%
a = csvread('csvlist_65_empty.dat')
%
% take a selection, starting from row 2 (index starts at 0); and column 0
%
m = csvread('csvlist_65.dat', 2, 0)
%{
% read a file containing also text (does it work?)
%
x = csvread('test.csv')
%}
%
% read a file containing also text (does it work?)
%
x = csvread('test-alltext.csv')





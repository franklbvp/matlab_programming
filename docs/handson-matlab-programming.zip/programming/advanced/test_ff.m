function y = test_ff(x)

%% test
% test publishing of a function

%% performing the calculations
a = x + 5;
b = a.^2;
z = a + b
%
% Purpose: demonstrate memory use when plotting
%
% source: G. Zucchelli - matlab seminar Mechelen
%

memory
y = rand(1250e3,1); % 10mb
memory
plot(y)
memory

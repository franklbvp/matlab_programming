%
% scroll row by row
%
clear
tic
n=5000; 
x = zeros(n);
for i=1:n       % rows
   for j=1:n    % columns
     x(i,j) = i+(j-1)*n;
   end
end
toc
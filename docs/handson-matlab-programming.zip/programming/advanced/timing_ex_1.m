%
% e = etime(t2,t1) returns the time in seconds between vectors t1 and t2. 
% The two vectors must be six elements long, in the format returned by clock:
%
% c = clock returns a 6-element date vector containing the current date and time in decimal form:
%
t0=clock;
i=0;
for t=0:.0001:50
   i=i+1;
   x =sin(t);
end
wall_f= etime(clock,t0);
fprintf('wall clock - for loop: %f \n', wall_f)

t0=clock;
Y=sin(0:.0001:50);
wall_v= etime(clock,t0);
fprintf('wall clock - vectorized: %f \n', wall_v)

t0=cputime;
i=0;
for t=0:.0001:50
   i=i+1;
   x = sin(t);
   Y(i)=x;
end
cpu_f=cputime-t0; 
fprintf('cputime - for loop: %f \n', cpu_f)


t0=cputime;
Y=sin(0:.0001:50);
cpu_v=cputime-t0;
fprintf('cputime - vectorized: %f \n', cpu_v)

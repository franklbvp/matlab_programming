function demo_publish_sine_wave

%% PLot Sine Wave
% Calculate and plot a sine wave
% file: demo_publish_sine_wave.m

%% Calculate and Plot a Sine Wave
% Define the range for x
%
% $$0 \leq x \leq 6\pi $$
%
% Calculate and plot |y = sin(x)|
x = 0:0.1:6*pi;
y=sin(x);
plot(x,y);

%% Modify Plot Properties
title('Sine Wave', 'FontWeight', 'bold');
xlabel('x');
ylabel('sin(x)');
%set(gca('Color', 'w'));
%set(gcf('Menubar', 'none'));
%
%
% driver routine for minDistance
%
x = [ 1 3 4 5 8 99 89.7  56.6  4  5];

y = [ 21 32 42 25 82 99 829.7  526.6  24  5];

z = [ 31 33 34 35 8 399 8339.7  536.6  4  45];

d1 = minDistance(x, y, z);

disp(d1);

d2 = minDistance_vec(x, y, z);

disp(d2);
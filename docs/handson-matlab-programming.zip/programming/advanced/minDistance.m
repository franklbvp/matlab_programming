function d = minDistance(x, y, z)

%
% given a set of spatial elements, calculate the minimal distance to the
% origin
% 

nPoints = length(x);
% d = zeros(nPoints, 1); % preallocate

for k = 1:nPoints
    d(k)= sqrt(x(k)^2+y(k)^2+z(k)^2);
end

d = min(d);

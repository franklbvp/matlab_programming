% fast_int.m
A=int8(zeros(10000));
tic
A=A+100;
toc
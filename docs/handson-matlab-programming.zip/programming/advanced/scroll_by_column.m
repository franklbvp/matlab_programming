%
% scroll column by column
%
clear
tic
n=5000; x = zeros(n);
for j=1:n      % columns
   for i=1:n   % rows
     x(i,j) = i+(j-1)*n;
   end
end
toc
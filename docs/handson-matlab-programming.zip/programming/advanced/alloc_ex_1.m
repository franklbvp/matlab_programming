%
% example allocation
%
% TODO: nothing - just a test
%
tic;
x = [3 5; 8 7];
%
% verify with y allocated or not
% 
y = zeros(1,100000);
for i=1:100000
    y(i)=det(x^i);
end
toc
i=0;

tic
for t=0:0.1:10
    i=i+1;
    y=sin(t);
end
toc

tic
t=0:0.1:10;
y=sin(t);
toc
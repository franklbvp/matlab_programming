function [surface] = surface_rectangle(base,height)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
surface = base .* height;
end


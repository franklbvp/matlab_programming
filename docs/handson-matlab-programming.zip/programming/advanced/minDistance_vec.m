function d = minDistance_vec(x, y, z)

%
% given a set of spatial elemnts, calculate the minimal distance to the
% origin
% 


d= min(sqrt(x.^2+y.^2+z.^2));

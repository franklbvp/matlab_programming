function [perimeter] = perimeter_rectangle(base,height)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
perimeter = 2 .* base + 2 .* height;
end


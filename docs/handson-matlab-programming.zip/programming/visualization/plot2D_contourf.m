%
% example contourf
%
[x, y] = meshgrid(-2:.1:2, -1:.1:1);
z = x.* exp(-x.^2-y.^2);

% Hndl1 is a handle allowing to access the object and its properties
Hndl1 = contourf(x, y, z);
colorbar;


pause
                          
get (gca)   % gca stands for "get current axes"
set(gca,'XTickLabel',['140W';'130W';'120W';'110W';'100W';' 90W';' 80W';' 70W';' 60W';' 50W';' 40W'])
% YTickLabel to change the labels on the y-axis                          

pause
% make the axis labels bigger and bold: 
set(gca,'FontSize',10,'FontWeight','bold')
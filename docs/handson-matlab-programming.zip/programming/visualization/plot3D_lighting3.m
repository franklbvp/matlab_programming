%
% example surf & lighting
%
[xx yy zz] = sphere;

subplot (2, 2, 1)
s = surf(xx,yy,zz);
title ('no effects')


subplot (2, 2, 2)
hs1 = surf(xx,yy,zz);
set(hs1,'EdgeColor','none', ...
    'FaceColor','red', ...
    'FaceAlpha','interp');
alpha('color');
alphamap('rampdown');
camlight(45,45);
lighting flat
title ('flat')


subplot (2, 2, 3)
hs1 = surf(xx,yy,zz);
set(hs1,'EdgeColor','none', ...
    'FaceColor','red', ...
    'FaceAlpha','interp');
alpha(.4)
%alphamap('rampdown');
camlight(45,45);
lighting phong
title ('phong')


subplot (2, 2, 4)
hs1 = surf(xx,yy,zz);
set(hs1,'EdgeColor','none', ...
    'FaceColor','blue',...
    'FaceAlpha','interp');
alpha(0.7)
%alphamap('rampdown');
lightangle(60, 45)
lighting gouraud
title ('gouraud')


%
% create a simple movie
%
% You can create animations by using the getframe and movie commands.
%
 
x = [0,0,0]

for i=1:10

    plot3(x(1),x(2),x(3),'r.','MarkerSize',20);
    M(i) = getframe;
    x = x + 0.1*rand(1,3);

end

movie(M,3) % play the movie three times

 
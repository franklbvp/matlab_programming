function [mav,uband,lband]= bolling(asset,samples,alpha)
%BOLLING Bollinger Band chart. 
%       BOLLING(ASSET,SAMPLES,ALPHA) plots Bollinger bands for
%       given ASSET data.  SAMPLES specifies the number of samples to use in
%       computing the moving average.  ALPHA is the exponent used to compute
%       the element weights of the moving average.  It does not return any
%       data.
%       
%       [MAV,UBAND,LBAND] = BOLLING(ASSET,SAMPLES,ALPHA) returns MAV
%       with the moving average of the asset data, UBAND with the upper band
%       data, and LBAND with the lower band data.  It does not plot any data. 
% 
%       BOLLING(ASSET,20,1) plots linear 20-day moving average Bollinger  
%       Bands. 
% 
%       [MAV,UBAND,LBAND] = BOLLING(ASSET,20,1) returns the data used to  
%       plot the linear 20-day moving average Bollinger Bands without  
%       plotting the data. 
% 
%       See also MOVAVG, HIGHLOW, CANDLE, POINTFIG. 
 
%       Author(s): C.F. Garvin, 2-23-95 
%       Copyright (c) 1995-1999 The MathWorks, Inc. All Rights Reserved. 
%       $Revision: 1.4 $   $Date: 1999/01/12 14:58:48 $ 
 
% error checking for input arguments 
if nargin < 1 
  error(sprintf('No input arguments specified.')) 
end 
if nargin < 2 
  error(sprintf('Please specify a moving average length.')) 
end 
if nargin < 3 
  alpha = 0; 
end 
 
[m,n] = size(asset); 
 
if m > 1 & n > 1 
  error(sprintf('Please enter ASSET data as a row or column vector.')) 
end 
 
asset = asset(:); 
r = length(asset); 
 
if samples < 2 | samples > r 
  error(sprintf('Please specify moving average length > 1 and < %1.0f.',r)) 
end 
 
% build weight vector 
i = (1:samples)'; 
w = i.^alpha./sum(i.^alpha); 
 
% build moving average vectors with for loops 
a = zeros(r-samples,1); 
b = zeros(r-samples,1); 
for i = samples:r 
  a(i-samples+1) = sum(asset(i-samples+1:i).*w); 
  b(i-samples+1) = 2*sum(std(asset(i-samples+1:i)).*w); 
end 
 
if nargout == 0 
  ind = samples:r; 
  h = plot(ind,asset(ind),ind,a,ind,a+b,ind,a-b); 
  if get(0,'screendepth') > 1 
    cls = get(gca,'colororder'); 
    set(h(1),'color',cls(1,:)) 
    set(h(2),'color',cls(2,:)) 
    set(h(3),'color',cls(3,:)) 
    set(h(4),'color',cls(3,:)) 
  end 
else 
  mav = a; 
  uband = a+b; 
  lband = a-b; 
end
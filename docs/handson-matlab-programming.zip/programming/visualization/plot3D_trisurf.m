%
% plot3D_trisurf.m
%
% woking with irregular spaced points
%
close all
clear

grid off

X = 2 * rand(100,1) - 1; 
Y = 2 * rand(100,1) - 1;
Z = exp(-(X.^2+Y.^2)) .* sin(10*X).*sin(10*Y);

plot3(X,Y,Z,'.y','markersize',25)

hold on
tri = delaunay(X,Y);
trisurf(tri, X, Y, Z);
colormap('gray')
grid on;
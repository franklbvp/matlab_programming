%
% source: http://stackoverflow.com/questions/38342244/how-can-i-create-a-slice-of-a-surface-plot-to-create-a-line-matlab
% taking a slice from a 3D plot
% 
% Create Data
z=peaks(50);

% Create x,y coordinates of the data
[x,y]=meshgrid(1:50);

% Plot Data and the slicing plane 
surf(z);
hold on

patch([0,0,50,50],[15,15,35,35],[10,-10,-10,10],'w','FaceAlpha',0.7);

% Plot an arbitrary origin axis for the slicing plane, this will be relevant later
plot3([0,0],[15,15],[-10,10],'r','linewidth',3);


% Since it is a plane, is relatively easy to obtain the x,y coordinates along 
% the slicing plane with linspace, 
% I'll get 100 points, and then interpolate those 100 points into the original data.

% Create x and y over the slicing plane
xq=linspace(0,50,100);
yq=linspace(15,35,100);

% Interpolate over the surface
zq=interp2(x,y,z,xq,yq); 

% Now that we have the values of z, we need what to plot them against,
% that's where you need to define an arbitrary origin axis for your splicing plane, 
% I defined mine at (0,15) for convenience sake, 
% then calculate the distance of every x,y pair to this axis, 
% and then we can plot the obtained z against this distance.

dq=sqrt((xq-0).^2 + (yq-15).^2);

figure
plot(dq,zq)

axis([min(dq),max(dq),-10,10]) % to mantain a good perspective
%
% data taken from
% http://physics.uku.fi/opiskelu/kurssit/MPM/
%
x = [-2:0.01:4];
y = 3*x.^3-26*x+6;
yd = 9*x.^2-26;
ydd = 18*x;

plot(x,y,'-b',x,yd,'--r',x,ydd,':k')



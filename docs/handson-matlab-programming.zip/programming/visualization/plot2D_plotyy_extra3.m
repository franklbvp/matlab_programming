%
% MATLAB code for plotyy example
x = 0:0.01:20;
y1 = 200*exp(-0.05*x).*sin(x);
y2 = 0.8*exp(-.5*x).*sin(10*x);

subplot(3,1,1); 
plot(x,y1);

subplot(3,1,2); 
plot(x,y2,'r:');

subplot(3,1,3);
[AX,H1,H2] = plotyy(x,y1,x,y2);
set(get(AX(1),'Ylabel'),'String','Left Y-axis')
set(get(AX(2),'Ylabel'),'String','Right Y-axis')
xlabel('Zeroto 20 \musec.')
set(H1,'LineStyle','--'); 
set(H2,'LineStyle',':')
set(H2,'Color','r')
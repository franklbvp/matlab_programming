clf reset
echo on
clc
%   A function called FPLOT is used to plot one or more function
%   with a given window. Here are some examples:

fplot('sin(x)',[0 4*pi])

% specify domain and range:

fplot('sin(x)',[0 4*pi -2 2])

% To get more than one function into the plot:

fplot('[sin(x),cos(x)]',[0 4*pi -2 2])

% There are lots of fancy graphing options that you can read
% about starting with the command HELP FPLOT. For example,

fplot('sin(x)',[0 4*pi],'-+')

% plot more than two graphs:

fplot('[exp(x),1,1+0.25*x,1+0.5*x,1+0.75*x]',[-1 1])

% or a movie might be helpful if you are not using the 
% student version of MATLAB

fplot('exp(x)',[-1 1 0 2.5]) % plot the function


for i=1:20

   a = 0.1*(i-1);  % determine the slope of the line
   s2 = @(x) 1+a*x;
   fplot(s2,[-1 1 0 2.5])
   text(-0.5,2,['slope = ',num2str(a)]) 
                   % plot graph and line
   m(:,i)=getframe; % save the plot in m
end

movie(m,1,2)  % play the movie once at two frames per second
              % (looks like it plays twice)

echo off
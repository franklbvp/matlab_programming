%
% example axes extra 1
%
clear
close all

x = 0.00:0.1:2*pi;
y1=sin(x+pi/10);
y2= sin(x-pi/10);

%first plot
h = plot(x, y1, '-', x, y2, '--')
axis tight;

z = abs(y1-y2);
% second plot inside first plot
axes('Position',[0.2 0.15 0.3 0.2]);
plot(x,z);
axis tight;
title('abs(sin(y1)-sin(y2)');

% use handle to put legend in first plot
legend(h, 'sin(y1)', 'sin(y2)');

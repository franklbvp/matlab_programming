%
% demo using the print command to save a figure
%
z = rand(1,10)*10;
plot(z);

print(gcf, '-djpeg', 'print_jpeg_def');
print(gcf, '-djpeg', '-r600', 'print_jpeg_600');
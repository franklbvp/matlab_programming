%
% plot_print_01
% demo print
%

% generate data

x = 1: 100;
y = sin(x);

h = figure; 
plot(x,y);

print(h,'-dps','Figure1.ps');
print(h,'-dpdf','Figure1.pdf');
% print(h,'-dsvg','Figure1.svg');
print(h,'-dpng','Figure1.png');

%
% mesh example
%
x=-5:0.5:5;
y=x;

[X Y]=meshgrid(x,y);
R=sqrt(25.0 - X.^2 - Y.^2);
CC = ones(size(X));

for i = 1:21
   for j = 1:21
      if imag(R(i,j)) ~= 0
         R(i,j) = 0+0i;
      end
   end
end
mesh(X,Y,R,CC);
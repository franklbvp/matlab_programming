clear
clc
clf

facets = 120; radius = 1;
thr = linspace(0, 2*pi, facets);
phir = linspace(0, pi, facets);
[th, phi] = meshgrid( thr, phir );
x = radius * cos(phi);
y = radius * sin(phi) .* cos(th);
z = radius * sin(phi) .* sin(th);
surf(x, y, z);
shading interp
colormap copper
axis equal, axis tight, axis off
lightangle(60, 45)


figure
[xx yy zz] = sphere;
surf(x, y, z);
shading interp
colormap copper
colormap hsv
alpha(.4)
axis equal, axis tight, axis off
lightangle(30, 45)

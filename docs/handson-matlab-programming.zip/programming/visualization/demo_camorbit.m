surf(peaks)
axis vis3d
for i=1:36
camorbit(10,0,'data',[0 0 1])
drawnow
M(i)=getframe(gcf,[5 5 550 410]);
end

movie(M);
movie2avi(M,'surf2.avi','compression','none');
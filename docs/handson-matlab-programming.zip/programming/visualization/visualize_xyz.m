%
% visualize (x,y,z) data
% based on http://nl.mathworks.com/help/matlab/visualize/representing-a-matrix-as-a-surface.html

% read data
xyz = importfilexyz('xyz_triplets.txt');

X = xyz(:,1);
Y = xyz(:,2);
Z = xyz(:,3);

x = reshape(X,5,5)';
y = reshape(Y,5,5)';
z = reshape(Z,5,5)';


stem3(x,y,z,'MarkerFaceColor','b');

figure
mesh(x,y,z);
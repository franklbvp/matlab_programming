function helix

pts = 0:pi/20:4*pi;

x1 = cos(pts); y1=sin(pts);
x2 = cos(pts+pi); y2=sin(pts*pi);
z=pts/(2*pi);

clf, whitebg(gcf,[0 0 0])
hold on
plot3(x1,y1,z,'y')
plot3(x2,y2,z,'w')

axis([-3 3 -3 3 0 2])
view(95,9)

colors='rgbm';
for i = 4:4:length(pts)-4
  plot3([x1(i) x2(i)], [y1(i) y2(i)], z([i i]), ...
      colors(ceil(rand(1)*length(colors))), ...
      'LineWidth', 3)
end

axis off
set(gcf,'Color','k')
set(gca,'CameraViewAngleMode','manual')

for az=-180:5:180
  view(az,9)
  drawnow
  pause(0.05)
end

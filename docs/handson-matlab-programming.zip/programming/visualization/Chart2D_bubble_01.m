% based on  http://msg.byu.edu/matlab/node22.html
%
% bubble plot
%
%
% let's select 10 random spots in the x-y plane and place a random charge 
% at each point. 
% The magnitude of the charge will vary from -50 to +50 pC. 
% Represent the position of the charge by it's place on the plot. 
% The magnitude of the charge will be represented by the size of the point, 
% and the sign of the charge will be indicated by color, blue for + and red
% for -

clear all % clear memory
clc; % clear command window
close all; % close any figure windows that are open


N = 10; % Number of charges to place

xq=rand(1,N); % x positions of the charges
yq=rand(1,N); % y positions of the charges

q=100*rand(1,N)-50; % magnitude of charges (between -50 and 50)

color = 1.5+sign(q)/2; % sign(q) returns 1 or -1, so color is 1 or 2

size = abs(q)*100; % Make size of points bigger for bigger magnitude of q

scatter(xq,yq,size,color,'filled','s','MarkerEdgeColor','k');
%scatter(xq,yq,size,color,'filled');

hold on; % add another plot on top
plot(xq, yq,'w+','MarkerSize',10) % add a cross in the center of the circles

axis square

%
% example fplot
% 
x1 = linspace(0, 5*pi);
x2 = 0: 0.5 : 5*pi;

y1 = sin(x1) .* cos(2 * x1);
y2 = sin(x2) .* cos(2 * x2);

plot(x1, y1);
title(' sin(x) * cos(2x) - 0:5*pi ');

pause
axis ([0 20 -2 2]);

pause
axis tight;

%
% first_plot3D
%

%
% 1. prepare your data
% 
z = peaks(20);
%
% 2. select window and position plot region
%
figure(1);
subplot(1, 1, 1);
%
% 3. call 3-D graphing function
%
h = surf(z);
%
% 4. set colormap and shading algorithm
%
colormap hot;
shading interp;
set(h, 'EdgeColor', 'k');
%
% 5. add lighting
%
light('Position',[-2, 2, 20]);
lighting phong 
material ([0.4,0.6,0.5,30])
set (h, 'FaceColor', [0.7 0.7 0],'BackFaceLighting','lit')
%
% 6. set viewpoint
%
view([30, 25]);
% To prevent resizing during rotation, you need to set the CameraViewAngleMode to manual
set(gca, 'CameraViewAngleMode','Manual');
%
% 7. set axis limits and tick marks
%
axis([0 20 0 20 -10 10]);
set (gca, 'Zticklabel', 'Negative || Positive')
%
% 8. set aspect ratio
%
%set(gca, 'PlotBoxAspectRatio',[2.5 2.5 1]);
%
% 9. annotate the graph
xlabel('X Axis');
ylabel('Y Axis');
zlabel('Function');
title ('Peaks');
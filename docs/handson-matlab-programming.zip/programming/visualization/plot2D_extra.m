%
%  example: some extra functions to plot
%

plot(0:pi/20:2*pi,sin(0:pi/20:2*pi),0:pi/20:2*pi,cos(0:pi/20:2*pi));

%
% label the axis
% multiple axis-labels in a cell array
%
xlabel('x-axis');
ylabel({'sine';'cosine'});

%
% putting a title
%
title ('plot extra demo');


%
% legend 
%
legend ('sine', 'cosine');


%
% some extra info  with text
%
text(pi,0,' \leftarrow sin(\pi)','FontSize',18)
N = 10; % Number of charges to place
 
xq=rand(1,N); % x positions of the charges
yq=rand(1,N); % y positions of the charges
 
q=100*rand(1,N)-50; % magnitude of charges (between -50 and 50)
 
color = 1.5+sign(q)/2; % sign(q) returns 1 or -1, so color is 1 or 2
 
size = abs(q)*100; % Make size of points bigger for bigger magnitude of q
 
scatter(xq,yq,size,color,'filled');
 
hold on; % add another plot on top
plot(xq, yq,'w+','MarkerSize',10) % add a cross in the center of the circles
 
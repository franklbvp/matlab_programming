%
% example quiver
%

[x,y] = meshgrid(0:0.2:2,0:0.2:2);
u = cos(x).*y;
v = sin(x).*y;

figure
quiver(x,y,u,v)


% draw horizontal and vertical line
hold on
plot([0 2],[1 1], 'r')
plot([1 1], [0 2.5] , 'r')


% select and plot data for a specific y-value
% 
% search row of y-value  (in this example y == 1
yrow = find(y == 1, 1);
xs = x(yrow, :);
us = u(yrow, :);
vs = v(yrow, :);


hold on;
[x,y,z] = sphere;
[i,j,k] = cylinder(3);
s2=surf(2.424*x, 2.424*y, (2.424*z)+2.424);
s3=surf(i./(11*k+1),j./(11*k+1),(11*k)+1);
s4=surf(6*x,6*y,(6*z)+6);
set(s2,'EdgeColor','k','FaceColor','k')
set(s2,'LineWidth',1)
set(s3,'EdgeColor','g','FaceColor','none'); 
set(s3,'LineWidth',2)
set(s4,'EdgeColor','r','FaceColor','none')
set(s4,'LineWidth',2)
axis([-6 6 -6 6 0 12]), axis off, grid off;
set(gca,'DataAspectRatio',[1 1 1]);
light;
view(-37.5,30);
shading interp;
material shiny;
lighting phong;
set(gcf,'color',[0.5 0.5 0.5]);
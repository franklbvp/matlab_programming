%
% experiment with hidden lines 
%
[X,Y,Z] = sphere(20);
subplot(1,2,1);
mesh(X,Y,Z) 
title('Opaque');
hidden on;
axis square off;
subplot(1,2,2);
mesh(X,Y,Z)
title('Transparent');
hidden off;
axis square off;

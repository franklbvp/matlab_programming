%
% scatter plot
%
% RAND(N) is an N-by-N matrix with random entries, chosen from
%    a uniform distribution on the interval (0.0,1.0).
% RANDN(N) is an N-by-N matrix with random entries, chosen from
%    a normal distribution with mean zero, variance one and standard
%    deviation one.
x = rand(40, 1);
y = randn(40, 1);

area = 20+(1:40);

scatter(x, y)
box on
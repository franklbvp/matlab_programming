%
% plotyy
%
x = 1:10;
y1 = sin(x);
y2 = 10*cos(x);
[ax,h1,h2] = plotyy(x,y1,x,y2);
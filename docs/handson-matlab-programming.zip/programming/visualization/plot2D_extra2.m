%
% plot2D_extra2
%

t = 0:pi/20:2*pi; 
y = exp(sin(t)); 

plot(t, y)

grid on

xlabel('variable t')

box off

axis off

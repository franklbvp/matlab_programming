%
% make a movie - Jan Verschelde code
%
figure % open new window
topeak = moviein(100); % 100 frames in movie

s = [-0.9 1.0 0.2]; % start position
p = [0.5 0.0 1.1]; % peak of membrane

membrane % make first plot

set(gca,'CameraPosition',s);
set(gca,'CameraTarget',p);
set(gca,'Projection','Perspective');

topeak(:,1) = getframe(gcf); % first frame of movie

dt = 0.01; % increment for positions
for i = 2:100 % create other frames
    s(1) = s(1) + dt; % move x coordinate of start
    s(2) = s(2) + 0.5*dt; % move y coordinate of start
    p(3) = p(3) + dt; % aim camera higher
    set(gca,'CameraPosition',s);
    set(gca,'CameraTarget',p);
    set(gca,'Projection','Perspective')
    topeak(:,i) = getframe(gcf); % store the frame
end;

% Play the animation saved in M in MATLAB
% Try the command below (uncommented) in the Command Window:
% movie(topeak)
% The animation in the Figure window plays once at 30 frames per second.

% Save the animation to play outside of MATLAB

%movie2avi(topeak, 'topeak.avi', 'fps', 30, 'quality', 100);


%
% movie with no figure display
%
%  use addframe
%
% test based on the matlab demo-file for the peaks-movie
%
% make the figure invisible
%
hfig= figure('visible','off');

Z = peaks; surf(Z); 
axis tight
set(gca,'nextplot','replacechildren');
% Record the movie
for j = 1:20 
    surf(sin(2*pi*j/20)*Z,Z)
    hframe= figure('visible','off');
    F(j) = getframe(hfig);
end

pause

% Play the movie 4 times
movie(F,4) 
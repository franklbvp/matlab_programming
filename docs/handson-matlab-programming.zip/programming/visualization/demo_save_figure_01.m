%
% graphics demo saving a plot
%
% http://stackoverflow.com/questions/4886195/save-matlab-figure-with-different-background-color
%


points = rand(100,3);
plot3(points(:,1),points(:,2),points(:,3),'*w')
grid on
set(gca,'Color',[0.5 0.5 0.5])

% this line of code is important to keep the settings
% For adjusting the figure in other ways, check out this link
% http://www.mathworks.com/help/techdoc/creating_plots/f3-84337.html
% check this by (re)moving the comment
%
set(gcf, 'InvertHardCopy', 'off');

saveas(gcf,'test1','pdf')
saveas(gcf,'test2','png')
print(gcf,'test3.pdf','-dpdf')






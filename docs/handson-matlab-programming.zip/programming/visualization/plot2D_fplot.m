%
% example fplot
% 
x1 = 0:5*pi;
x2 = 0: 0.5 : 5*pi;

y1 = sin(x1) .* cos(2 * x1);
y2 = sin(x2) .* cos(2 * x2);


subplot (3,1,1);
plot(x1, y1);
title(' sin(x) * cos(2x) - 0:5*pi ');

subplot (3,1,2);
plot(x2, y2);
title(' sin(x) * cos(2x) - 0:0.5:5*pi ');


subplot (3,1,3);
fplot('sin(x) .* cos(2*x)', [0 5*pi]);
title(' sin(x) * cos(2x) - fplot ');
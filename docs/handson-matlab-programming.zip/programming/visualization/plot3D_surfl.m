%
% example surfl
%
[x, y, z] = peaks(100);
surfl(x,y,z);

% The shading function controls the color shading.
shading interp;

figure
surfc(x,y,z);

% The shading function controls the color shading.
% shading interp;
[x,y,z] = peaks(10);
surf(x,y,z);

% go from 3D to 2D
view(2)
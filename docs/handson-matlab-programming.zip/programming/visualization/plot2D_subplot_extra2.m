%
% subplot extra example 2
%
close all;
clear

% generate data
x = 0:0.01:2*pi;
y1=sin(x);
y2=cos(x);
y3=exp(-x/4).*sin(x);
y67=rand(1, length(x))/10+sin(x);
y81=exp(-x/4);
y91=rand(1, length(x))/10+cos(x);

%generate plots

subplot(3,5,1);
plot(x,y1), axis tight, title('1');

subplot(3,5,2);
plot(x,y2), axis tight, title('2');

subplot(3,5,3:5); 
plot(x,y3), axis tight, title('3-5');

subplot(3,5,[6 7 11 12]);
plot(x,y67), title('[6 7 11 12]');

subplot(3,5,[8 13]);
plot(x,y81), axis tight, title('[8 13]');

subplot(3,5,[9 10 14 15]);
plot(x,y91), axis tight, title('[9 10 14 15]');

x = 1:10
y = x.^2
figure
plot(x,y)
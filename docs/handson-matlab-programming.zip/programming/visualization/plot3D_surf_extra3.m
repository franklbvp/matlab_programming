[x,y,z] = peaks;
surf(x,y,z,z)
surf(x,y,z,x)
surf(x,y,z,rand(length(x)))
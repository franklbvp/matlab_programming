%
% meshc / meshz example using the peaks function
%
[x,y,z]=peaks(30);
surf(x,y,z)
axis tight
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')

figure
surf(x,y,z)
shading flat
axis tight
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')

figure
surf(x,y,z)
shading interp
axis tight
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
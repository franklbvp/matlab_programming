% 
% scatter plot
%

clear all % clear memory
clc; % clear command window
close all; % close any figure windows that are open


N = 50; % Number of data points

% generate the data
xdat = rand(1,N);
ydat = rand(1,N);


% use the plot function
% specify the marker and no line style to draw only points
figure;
plot(xdat, ydat, 'o');

% use the scatter function
figure;
scatter(xdat, ydat);

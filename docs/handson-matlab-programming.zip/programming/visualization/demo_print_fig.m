%
% demo print figure
%
x = 1:100;
y = sin(x);
z = cos(x);


plot(x,y);
print('plot_sin', '-dpng');


figure
plot(x,z);
print('plot_cos', '-dpng');

surf(peaks(30));
% export as pdf
saveas(gcf,'surf_saveas.pdf')
print -painters -dpdf -r600 surf_print.pdf

% export as jpg
saveas(gcf,'surf_saveas.jpg')
print -painters -djpeg -r600 surf_print.jpg
%
% example Compass plots
% plotting wind direction/strength on a circular grid
%
% Work in radians:
%
xv = pi/180 * [215 275 130 25 95];
yv= [15 13 8 6 9]    %(corresponding wind strengths)
%
%Convert from polar to cartesian coordinates
%
[x,y] = pol2cart(xv,yv);
%
% plot it
%
compass(x,y)
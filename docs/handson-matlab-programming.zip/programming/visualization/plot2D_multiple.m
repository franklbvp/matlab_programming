%
t = 0:1:12;
a = 1;
b = 2;

figure(1)
f=(exp(-a*t)-exp(-b*t))/(b-a);
plot(t,f,'r-.')

hold on

a = 3;
b = 5;

f=(exp(-a*t)-exp(-b*t))/(b-a);
plot(t,f,'b--')

figure(2)
a = 0.4
b = 0.7
plot(t,f)

cla

whitebg([0 .5 .6])
a = 0.2
b = 0.7
plot(t,f)

clf 

close(1)
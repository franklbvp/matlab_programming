%
% Simple plot script
% http://faculty.cua.edu/regalia/CSC113/default.htm


% Create range of x values and their squares:
%
xx = linspace(-1.1,1.1,200);
xx2 = xx .* xx;
%
% Chevyshev polynomials of orders 4 and 5:
%
% T_4(x) = 8 x�4 - 8 x�2 + 1
% T_5(x) = 16 x�5 - 20 x�3 + 5 x
%
T4 = (8 * xx2 - 8) .* xx2 + 1;
T5 = ((16 * xx2 -20) .* xx2 + 5) .* xx;
figure(1);
plot(xx,T4,'linewidth',2);
axis([-1.1 1.1 -5 5]);
hold on
plot(xx,T5,'r','linewidth',2);
%
% Draw a dashed square box,
% to highlight the equi-ripple region of the
% Chebyshev polynomials:
%
xpath = [-1 -1 1 1 -1];
ypath = [-1 1 1 -1 -1];
plot(xpath,ypath,'-.');
hold off

% set the font size
set(gca, 'fontsize', 18)

xlabel('Input argument', 'fontsize', 18);
ylabel('Function value', 'fontsize', 18);
legend('T_4(x)', 'T_5(x)','Location','SouthEast');

%
% save plot
%
print -dpng figplot.png
print -djpeg figplot.jpg
print -dtiff figplot.tiff

% save it in black / white
print -deps2 figplotbw.eps

% save it in color eps
print -depsc2 figplot.eps
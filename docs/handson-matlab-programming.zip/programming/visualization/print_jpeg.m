for i=1:4096
A(i) = sin(i*2*pi/4096);
end

plot(A)
print ('-r600','-djpeg','plot600.jpg')


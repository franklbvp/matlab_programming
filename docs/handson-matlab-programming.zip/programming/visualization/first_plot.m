%
% plot your data: the steps
%
% 1. prepare your data
%
x = 0:0.2:12;
y1 = bessel(1,x);
y2 = bessel(2,x); 
%
% 2. select a window and position a plot region
%
figure(1)
subplot(2,2,1)
%
% 3. call plot function
%
h = plot(x, y1, x, y2)
%
% 4. select line and marker characteristics
%
set(h,'LineWidth',2,{'LineStyle'},{'--';':'}) 
set(h,{'Color'},{'r';'b'})
%
% 5. set axis limits, ...
%
axis([0 12 -0.5 1])
grid on
%
% 6. annotate the graph
%
xlabel ('Time')
ylabel ('Amplitude')
legend(h,'First','Second')
title('Bessel Functions') 
[y,ix] = min(y1); 
text(x(ix),y,'First Min \rightarrow' ,...
'HorizontalAlignment' ,'right')

% [Y,I] = MIN(X) returns the indices of the minimum values in vector I.
%    If the values along the first non-singleton dimension contain more
%    than one minimal element, the index of the first one is returned.
%
% script_01
%
a = 1;
b = 1.2
c = a + b

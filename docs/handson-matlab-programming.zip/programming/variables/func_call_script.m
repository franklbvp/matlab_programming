function [outputArg1,outputArg2] = func_call_script(var1,var2)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

script_01;

outputArg1 = var1 .* 2;
outputArg2 = var2 .* 3;
end


%% Main function to generate tests - you don't need to change this
function tests = exampleTest
tests = functiontests(localfunctions);
end

%% Test Functions
function test_add(testCase)
a = 1;
b = 2;
actual_result = add(a,b);
expected_result = a + b;
verifyEqual(testCase, actual_result, expected_result)
end
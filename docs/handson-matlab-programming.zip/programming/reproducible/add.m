function result = add(a,b)
  result = a + b;
end
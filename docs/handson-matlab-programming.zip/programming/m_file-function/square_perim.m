% square_perim
% calculate the perimeter of a square
%
% required variables: b
% result: p
p = 4 * b
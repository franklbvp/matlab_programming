function [outputArg1] = some_calc(inputArg1,inputArg2)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

a = inputArg1 + inputArg2;
b = inputArg1 .* inputArg2;

outputArg1 = a ./ b;

end


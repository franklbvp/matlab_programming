% rect_perim
% calculate the perimeter of a reactangle
%
% required variables: b, h
% result: p
p = 2*(b + h)
%
% geometrical_objects_v2
% calculate the perimeter and surface of 5 geometrical objects
% use scripts, the variables need to be in the workspace!

clear
clc

% rectangle
b = 5
h = 3
rect_area
rect_perim
s1 = s
p1 = p

% rectangle
b = 4.85
h = 3.69
rect_area
rect_perim
s2 = s
p2 = p

% triangle
b = 123.3
h = 30.14
side1 = 123.3
side2 = 100
side3 = 41.1052
tri_area
tri_perim
s3 = s
p3 = p

% square
b = 74.5
square_area
square_perim
s4 = s
p4 = p


% circle
b = 20 % b is radius
circle_area
circle_perim
s5 = s
p5 = p

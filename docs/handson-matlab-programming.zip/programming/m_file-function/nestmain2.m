function nestmain2
nestfun2
   function nestfun2
      x = 5;
   end 
x = x + 1;
fprintf('nestmain1 - x = %d\n', x)
end

function nestmain1
x = 5;
nestfun1
   function nestfun1 
     x = x + 1;
   end 
fprintf('nestmain1 - x = %d\n', x)
end

%   
%   First have a contiguous set of comment lines to be printed out
%   by the help command.  These comments should:
%
%   1) Describe what the function does.
%   2) Specify the arguments the function takes.
%   3) Specify what the function returns.
%     
%   Then have some internal comments that give:
%
%   1) The author of the code.
%   2) The date the code was written.
%   3) Dates of revisions and descriptions of the changes.

function [outputArg1, outputArg2, ...] = fName(inputArg1, inputArg2, ...)

    ....

    Your code, which will eventually assign values to 
    outputArg1, outputArg2, etc.

    ...

return;                           % This is optional.
                                  % When the end of the function
                                  % is reached, control returns to
                                  % the calling program anyway.

function [outputArg1,outputArg2] = myfirstfunction(inputArg1,inputArg2)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
t1 = inputArg1;
t2 = inputArg2;
r1 = t1 + t2;
r2 = t1 * t2;
outputArg1 = r1;
outputArg2 = r2;
end


%
% example of local functions
% taken from https://nl.mathworks.com/help/matlab/matlab_prog/types-of-functions.html
%
function b = myfunction(a)
   b = squareMe(a)+doubleMe(a);
end
function y = squareMe(x)
   y = x.^2;
end
function y = doubleMe(x)
   y = x.*2;
end
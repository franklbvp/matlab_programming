%
% error testing
%
a = randi(50,5);
disp(a(6,6));
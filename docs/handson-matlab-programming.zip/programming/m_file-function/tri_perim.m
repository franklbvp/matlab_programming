% tri_perim_s.m
%
% calculate the perimeter of a triangle
%
% required variables: side1, side2, side3
% result: p

p = side1 + side2 + side3
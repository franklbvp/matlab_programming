function [outputArg1,outputArg2] = mycalc(inputArg1,inputArg2)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

r1 = inputArg1 + inputArg2;
r2 = inputArg1 * inputArg2;

outputArg1 = r1;
outputArg2 = r2;

end


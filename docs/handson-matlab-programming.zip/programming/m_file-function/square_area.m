% square_area
% calculate the surface of a square
%
% required variables: b
% result: s
s = b * b
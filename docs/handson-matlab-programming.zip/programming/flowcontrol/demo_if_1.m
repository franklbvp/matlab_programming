%
% demo if statement: demo_if_1
%
% nested if statements
%

a = input(' enter a value for a : ');

if a < 0
    a = 0;
    fprintf('negative value is reset to 0')
end

b = a;
res = sqrt(b)
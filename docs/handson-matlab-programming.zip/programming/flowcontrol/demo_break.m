%
% break example
%
% rem: input
% input can also return user input as a string, rather than a numeric value. To obtain string input,
%       append 's' to the function's argument list.
%
%       name = input('Enter address: ','s');
%
while(1)
  req=input('enter number or q to stop:','s');
  if (req == 'q')
      break
  end  
  disp(req);
end 

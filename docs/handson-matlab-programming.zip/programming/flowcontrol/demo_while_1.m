n = 1000;      % number
p = 1;
i = 1;
% determine p such that  2^p is larger than n
while (p < n)
%    p = p * 2;
    p = p;
    v(i) = p;
    i = i+ 1;
end
fprintf ( '%d is larger than %d ', p, n);

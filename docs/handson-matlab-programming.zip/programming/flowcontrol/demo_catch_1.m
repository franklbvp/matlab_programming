%
% try catch example
%
a = [1 2 -33 8 3];
%
%try
    % show an element from the vector
    index = input('enter index for an element of array a: \n');
    disp (['a(' int2str(index) ') = ' num2str(a(index))]);
%catch        
%    disp (['illegal subscript']);
%end

x = rand(1,5);
if any(x <.5)
    disp('in the if part')
end
disp(x)
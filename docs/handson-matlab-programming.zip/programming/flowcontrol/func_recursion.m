function [x]=func_recursion(y)
%
% this function is useful to test Matlab and recursion
% this function divides the number by 2 as long as the number is greater
% than 0
%
y=y/2

if (y>0)
   y=func_recursion(y);
end
x=y;

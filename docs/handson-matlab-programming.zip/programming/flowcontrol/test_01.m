for i = 1:10
    x = i * 1
    y = i * 7
end
a = 1
%
% a script with the only purpose of creatingsome variables
%
v1 = 1.2
v2 = 1:10
v3 = rand(4)
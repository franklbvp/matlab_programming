%
% calculate sum of 1 up to 100
%
% do it with a for loop

sum100 = 0;

for (i=1:1:100)
    sum100 = sum100 + i;
end

disp('sum100 = ');
disp(sum100)

%
% demo sequence
% 
%
N	= 5				    % a scalar

% a variable can contain different data types
v 	= [1 0 0]			% a row vector
v 	= [1;2;3]			% a column vector
v 	= v'				% transpose a vector 
						%(row to column or column to row)
v	= [1:.5:3]			% a vector in a specified range: 
v	= []				% empty vector

% no auto-update
r = 1.0
u = 0.5 + sqrt(3 + r)
r = 2 * pi 
% What is the value of u now?
u
%
% switch example determining day
%
%
dayNum = input(' enter number of day: ');

%
switch dayNum
    case 1
        dayName = 'Monday'
    case 2
        dayName = 'Tuesday'
    case 3
        dayName = 'Wednesday'
    case 4
        dayName = 'Thursday'
    case 5
        dayName = 'Friday'
    case{6, 7}
        dayName = 'Weekend'
    otherwise
        dayName = 'illegal'
end
% demo_switch_EvenOrOdd.m
%
%
% Input: a non-negative integer less than or equal to 10
%
% Output: 'Even', 'Odd', or 'You must enter a non-negative integer less
% than or equal to 10'
%
% Author: J Reising 
%
n = input('Enter a non-negative integer <= 10 ');
switch n
 case {0,2,4,6,8,10}
 fprintf('\n\nEven\n\n')
 case {1,3,5,7,9}
 fprintf('\n\nOdd\n\n')
 otherwise
 fprintf('\n\nYou did not enter a non-negative integer <= 10\n\n')
end
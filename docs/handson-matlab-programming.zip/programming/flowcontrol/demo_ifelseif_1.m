%  
% based on
%   ___________________________________
%   Jacob Y. Kazakia   jyk0
%   September 28, 2001
%   __________________________________
%   Purpose: This program compares the car emissions for four different
%            pollutants to given emissions limits.  The age of the car is taken
%            under consideration.  An appropriate message is printed.
%   Algorithm: The pollutant is selected by choosing an integer ( pol_number)
%              from a menu of the form:
%              (1) Carbon monoxide
%              (2) Hydrocarbons
%              (3) Nitrogen oxides
%              (4) Non-methane hydrocarbons
%              It prompts the user to enter the emission (emission) in grams
%              per mile.
%              It prompts the user to enter the odometer reading ( odom).
%              Compares the entered value to the limits given in the
%              following table ( from Joseph Priest, Energy:Principles, Problems,
%              Alternatives[ Addison-Wesley, 1991] ):
%                         First 5 Years or           Second 5 Years or
%                         50,000 Miles               Second 50,000 Miles
% carbon monoxide            3.4  gr/mile              4.2  gr/mile
% hydrocarbons               0.31   "  "               0.39   "   "
% nitrogen oxides            0.4    "  "               0.5    "   "
% Non-methane hydrocarbons   0.25   "  "               0.31   "   "

fprintf('\n  (1) Carbon monoxide ');
fprintf('\n  (2) Hydrocarbons ');
fprintf('\n  (3) Nitrogen oxides ');
fprintf('\n  (4) Non-methane hydrocarbons ');

pol_number = input(' \n\n Enter a pollutant number  >>>  ');
emission = input(' \n\n Enter the emission in grams per mile  >>>  ');
odometer = input(' \n\n Enter odometer reading >>>  ');


if( pol_number == 1 &  odometer <= 50000 & emission <= 3.4 )
    fprintf(' \n\n  permissible emission of carbon monoxide \n');
    fprintf(' continue to use this car \n');
elseif ( pol_number == 1 &  odometer <= 50000 & emission >  3.4 )
    fprintf(' \n\n  non permissible emission of carbon monoxide \n');
    fprintf(' get a new car \n');
elseif ( pol_number == 1 &  odometer > 50000 & emission <= 4.2 )
    fprintf(' \n\n  permissible emission of carbon monoxide \n');
elseif ( pol_number == 1 &  odometer > 50000 & emission  > 4.2 )
    fprintf(' \n\n  non permissible emission of carbon monoxide \n');
    
    %  Second pollutant
elseif ( pol_number == 2 &  odometer <= 50000 & emission <= 0.31 )
    fprintf(' \n\n  permissible emission of Hydrocarbons \n');
elseif ( pol_number == 2 &  odometer <= 50000 & emission >  0.31 )
    fprintf(' \n\n  non permissible emission of Hydrocarbons \n');
elseif ( pol_number == 2 &  odometer > 50000 & emission <= 0.39 )
    fprintf(' \n\n  permissible emission of Hydrocarbons \n');
elseif ( pol_number == 2 &  odometer > 50000 & emission  > 0.39 )
    fprintf(' \n\n  non permissible emission of Hydrocarbons \n');
    
    
    %  third pollutant
elseif ( pol_number == 3 &  odometer <= 50000 & emission <= 0.4 )
    fprintf(' \n\n  permissible emission of Nitrogen oxides \n');
elseif ( pol_number == 3 &  odometer <= 50000 & emission >  0.4 )
    fprintf(' \n\n  non permissible emission of Nitrogen oxides \n');
elseif ( pol_number == 3 &  odometer > 50000 & emission <= 0.5 )
    fprintf(' \n\n  permissible emission of Nitrogen oxides \n');
elseif ( pol_number == 3 &  odometer > 50000 & emission  > 0.5 )
    fprintf(' \n\n  non permissible emission of Nitrogen oxides \n');
    
    % fourth pollutant
elseif ( pol_number == 4 &  odometer <= 50000 & emission <= 0.25 )
    fprintf(' \n\n  permissible emission of Non-methane hydrocarbons \n');
elseif ( pol_number == 4 &  odometer <= 50000 & emission >  0.25 )
    fprintf(' \n\n  non permissible emission of Non-methane hydrocarbons \n');
elseif ( pol_number == 4 &  odometer > 50000 & emission <= 0.31 )
    fprintf(' \n\n  permissible emission of Non-methane hydrocarbons \n');
elseif ( pol_number == 4 &  odometer > 50000 & emission  > 0.31 )
    fprintf(' \n\n  non permissible emission of Non-methane hydrocarbons \n');
    
    %   invalid entry
else
    fprintf(' \n\n  You entered an invalid pollutant number');
    fprintf(' \n  Program will terminate  \n');
end

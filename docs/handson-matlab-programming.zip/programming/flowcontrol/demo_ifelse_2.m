%
% example if else
%

a = input(' enter a value for a : ');


if a >= 0
    disp('a >= 0 - sqrt can be computed');
    b = sqrt(a);
    disp(b);
else
    disp ('a is negative - take abs value');
    b = sqrt(abs(a));
    disp(b);
end
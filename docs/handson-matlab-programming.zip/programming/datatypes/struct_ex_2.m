%
% example structure
%
circle.radius = 2.5;
circle.center = [0 1];
circle.linestyle = '--';
circle.color = 'red';
%
circle
%
%pause
%
circle(2).radius = 3.4;
circle(2).center = [2.3 -1.21];
circle(2).linestyle = ':';
circle(2).color = 'green';
%
circle
%
%pause
%
% manipulations
%
area2 = pi * circle(2).radius^2
%
%pause
%
fieldnames(circle)
%
% add field
%
circle(2).filled = 'yes'
%
%pause
%
% retrieve fieldnames
%
bfnamen = fieldnames(circle)
%
% 
% new structure, the field 'filled' is removed
%
circle2 = rmfield(circle, bfnamen(5))
%
circle2
%
%pause
%
% test structure functions 
%
rad1 = getfield(circle, {1}, 'radius', {1})
%
%pause
%
circle = setfield(circle, {2}, 'color', 'blue')
circle(2)
%
%
%  demo_string
%
clc
clear

t = 'this is a string'
%
size(t)
%
% view the contents
%
u = double(t)
%
% use char to perform the inverse operation
%
char(u)
%
% some operations
u = t(11:16)
u = t(16:-1:1)
u = t'

%
% a matrix with names
%group = ('Jan', 'Arnoud','Karel', 'Paul')  %error
group1 = char('Jan', 'Arnoud','', 'Karel', 'Paul')
size(group1)
group2 = strvcat('Jan', 'Arnoud','', 'Karel', 'Paul')
size(group2)
%
% conversion functions
%
% integer to string
u = int2str(eye(3))
%
% matrix becomes an array of a characters
u1 = double(u(1, :))
u2 = char(u1)
%
% non-integer to string
s = rand(3,5)

precision = 3
s0 = num2str(s, precision)
%
% matrix becomes an array of a characters
s1 = double(s0(3, :))
s2 = char(s1)
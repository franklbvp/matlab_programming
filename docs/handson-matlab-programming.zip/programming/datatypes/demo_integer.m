%
% demo_integer.m
%
% showing some features of integers
%
clear
%
intmax('int8')
intmin('int8')
intmax('uint64')
intmin('uint64')
%
m = zeros(2,6, 'int8')
class(m)
whos
%
% explicit casting using the cast function
k = 1:7
class(k)
kk = uint8(k)
class(kk)
kkk = cast(k, 'uint16')
class(kkk)

% be careful
x=int8(60);
y=int8(70);
z=x+y

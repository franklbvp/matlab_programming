%
% structure of arrays or arry of structures?
%

% structure of arrays
data.x = linspace(0, 2*pi);
data.y = sin(data.x);

% array of structures
people(1).name = 'jeff';
people(1).age = 12;

people(2).name = 'ann';
people(2).age = 15;

people(3).name = 'john';
people(3).age = 32;

% create array of struct
names = {'Peter','Paul','Mary'};
ages = {25,29,26};
[people(4:6).name] = names{:};
[people(4:6).age] = ages{:};
%
%
% struct_ex_3
%
x.Axis = [0:99];                  % Time Axis
x.Data = sin(x.Axis); % Sinusoidal Data
x.Name = 'Sinusoidal Data';         % Signal Name


plot( x.Axis , x.Data );
title( x.Name );

%
% demo cell array
%
third = cell(3,1);

third(1,1) = {'happy'}; % cell index
third{2,1}='birthday';
third{3,1} = 90;
%
third
%
third(1,1), third{1,1}
third(2,1), third{2,1}
third(3,1), third{3,1}
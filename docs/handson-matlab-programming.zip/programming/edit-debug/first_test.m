%
% put some information
%

a = 1;
b = 1.2;
c = a + b;

c = cos(a);
c_1 = sin(a);


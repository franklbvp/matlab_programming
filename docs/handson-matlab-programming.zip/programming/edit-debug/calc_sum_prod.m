function [outputArg1,outputArg2] = calc_sum_prod(inputArg1,inputArg2)
%calc_sum_prod Summary of this function goes here
%   calculate sum and product
var1 = 12;
var2 = 3.4;
res = var1 * var2;
outputArg1 = inputArg1 + inputArg2 + res;
outputArg2 = inputArg1 * inputArg2 * res;
end


%% put some data in workspace

clear
close

% variables a and b

a = 5;
b = [1 2];

%% Prepare image data
% use the standard matlab function image to display the image
figure
x = 1:10
y = a*cos(x);
%% Display the image
plot(x,y);

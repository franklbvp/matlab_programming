%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MATLAB: introduction
% 
% compilation from:
% http://www.cs.dartmouth.edu/~farid/teaching/cs88/matlab.intro.html
% http://www.cs.iastate.edu/~cs474/MATLAB/matlab-primer.pdf
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) Help and basics
%
% Welcome to a tour of matlab. 
%
%
% critical matlab commands (online help is very useful, you should be able to do a lot 
% without ever looking at a manual.:
%
% help
%      yields a list of topic areas that you can get help on
%
% help general
%      picking the first of the topic areas, this command lists
%      all of the subtopic areas within the first topic
%
% help command
%      shows on-line help on the command
%
% doc command
%      displays the start page for the online doc
%
% If you don't know the exact name of the topic or command you are looking for,
% type "lookfor keyword" (e.g., "lookfor regression")
%
% try this at the command line:
%
% help lookfor
% doc lookfor
% lookfor complex
%
%
% Useful hints:
%
% If you want to stop matlab while it is doing something, hit control-c
%
% The symbol "%" is used in front of a comment.
%
% When writing a long matlab statement that exceeds a single row use ...
% to continue statement to next row.
%
% When using the command line, a ";" at the end means matlab will not
% display the result. If ";" is omitted then matlab will display result.
%
% Use the up-arrow to recall commands without retyping them (and down
% arrow to go forward in commands).  
%
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) Objects in matlab -- the basic objects in matlab are scalars,
% vectors, and matrices...

N	= 5				    % a scalar
v 	= [1 0 0]			% a row vector
v 	= [1;2;3]			% a column vector
v 	= v'				% transpose a vector 
						%(row to column or column to row)
v	= [1:.5:3]			% a vector in a specified range: 
v	= pi*[-4:4]/4			% 	[start:stepsize:end]
v	= []				% empty vector


m 	= [1 2 3; 4 5 6]		% a matrix: 1ST parameter is ROWS
					% 	    2ND parameter is COLS 
m	= zeros(2,3)   			% a matrix of zeros
v	= ones(1,3)  			% a matrix of ones
m	= eye(3)			% identity matrix
v	= rand(3,1)			% rand matrix (see also randn)


a=[1 2
   3 4]                 % define a 2x2 matrix a

b=[1,2;3,4]             % define a 2x2 matrix b
  
c=1:3               % define a 1x3 matrix c:
                    % note how the start:finish yields a sequence between start and finish
 
cp=c'               % the define a 3x1 matrix cp, here the ' indicates "transpose"

d=[1:2:6,2:2:6]     % define a 1x6 matrix:
                    % Now we are generating two 1x3 matricesand merging them together using
                    %the brackets. 
e=[1:2:6;2:2:6]

who                 % let's look over what we have created:

a
a(:,1)          % access a matrix column (1st column)
a(:,2)
a(2,:)          % access a matrix row (2nd row)
a(2,1)
a(2,1)=5         % note how we indexed a single element of the matrix

f=1
g=3
e(f,g)=200       % note how we used variables to index the matrix
e(:,2:3)
e(:,2:3)=b


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (3) Simple operations on vectors and matrices

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (A) Pointwise (element by element) Operations:

% addition of vectors/matrices and multiplication by a scalar
% are done "element by element"
a	= [1 2 3 4];			% vector
2 * a 					% scalar multiplication
a / 4					% scalar multiplication
b	= [5 6 7 8];			% vector
a + b					% pointwise vector addition
a - b					% pointwise vector addition
a .^ 2					% pointise vector squaring (note .)
a .* b					% pointwise vector multiply (note .)
a ./ b					% pointwise vector division (note .)

log( [1 2 3 4] )			% pointwise arithmetic operation
round( [1.5 2; 2.2 3.1] )		% pointwise arithmetic operation 
                                % round(X) rounds the elements of X to the nearest integers. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (B) Vector Operations (no for loops needed)
% Built-in matlab functions operate on vectors, if a matrix is given,
% then the function operates on each column of the matrix

a	= [1 4 6 3]			% vector
sum(a)					% sum of vector elements
mean(a)					% mean of vector elements
var(a)					% variance
std(a)					% standard deviation
max(a)					% maximum


a 	= [1 2 3; 4 5 6]		% matrix
mean(a)                      		% mean of each column
mean(a')'
max(a)                       		% max of each column    
max(max(a))		     		% to obtain max of matrix 
max(a(:))		     		% 	or...


%%%%%%%%%%%%%%%%%%%%%%%%
% (C) Matrix Operations:

[1 2 3] * [4 5 6]'  			% row vector 1x3 times column vector 3x1 
                    			% results in single number, also
                   			% known as dot product or inner product

[1 2 3]' * [4 5 6]  			% column vector 3x1 times row vector 1x3
                    			% results in 3x3 matrix, also
                    			% known as outer product

a	= rand(3,2)			% 3x2 matrix
b	= rand(2,4)			% 2x4 matrix
c	= a * b				% 3x4 matrix

a	= [1 2; 3 4; 5 6]		% 3 x 2 matrix
b	= [5 6 7];			% 3 x 1 vector
b * a					% matrix multiply
a' * b'					% matrix multiply

a = rand(2,2)
ai = a^(-1)        % inverse of a
aii = inv(a)       % also the inverse
ai*a             % just to check

exp(a)           % you can even take the exponent of a matrix

m
size(m)					% size of a matrix
size(m,1)  				% number rows
size(m,2)  				% number of columns

m1	= zeros(size(m))		% create a new matrix with size of m
 
i=3*ones(3,5)
j=2*ones(2,5)

net=[i;j]           %  merge two matrices, i & j into a single matrix.
 
k=9*ones(5,3)
l=4*ones(5,2)
net=[k';l']'

vl = linspace(5, 10, 10) % linspace(X1, X2, N) generates N points between X1 and X2.
    
a = [1 2 3; 4 5 6; 7 8 9] 
ar = rot90(a)       % rotates matrix a counterclockwise by 90 degrees.
af = fliplr(a)      % flip matrix left-to-right 
af = flipud(a)      % flip matrix up-to-down 

v = [1 2 3]
av = diag(v)        %diag(v), where v is a vector with n components, returns an n-by-n diagonal matrix having v as its main diagonal. 

a = [1 2 3; 4 5 6; 7 8 9]
atl = tril(a)       % lower triangular part 
atu = triu(a)       % upper triangular part 

R = randn(2,2,3)    % multidimensional matrices are also possible




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(4) Saving your work

save mysession      			% creates mysession.mat with all variables
save mysession1 atu  atl  			% save only variables a and b

clear all				% clear all variables

load mysession1				% load session
atu
atl


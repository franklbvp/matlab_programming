a = [1:100];
b = sin(x)

plot(x,y)
%
% script calling other scripts
%

a = 1

test_01

test_02

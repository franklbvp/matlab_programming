x(1) = 1
for i = 1: 10
    x(i) = x(i-1) + sqrt(i-2)
end
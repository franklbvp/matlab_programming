% script_using_dummy

disp('in script_using_dummy');

dummy_50 = 50 * dummy;
disp(dummy_50);

dummy_10 = 5;
disp(dummy_10);

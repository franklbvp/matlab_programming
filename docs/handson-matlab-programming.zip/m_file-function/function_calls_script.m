function function_calls_script(dummy)



% this function is calling a script
% check if there are any variables in the base workspace

dummy_10 = dummy * 10

% call a script

script_using_dummy

dummy_20 = dummy - 20
dummy_50
dummy_10
% circle_area
% calculate the surface of a circle
%
% required variables: b (radius)
% result: s
s = pi * b^2
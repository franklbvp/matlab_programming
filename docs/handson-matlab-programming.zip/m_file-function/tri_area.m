% tri_area_s.m
% taken from MathWorks
%
% calculate the surface of a triangle
%
% required variables: b, h
% result: s

s = 0.5*(b * h)
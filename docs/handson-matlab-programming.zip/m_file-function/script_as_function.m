function script_as_function
% script for:
% - generating random data points
% - plot data points
%
% test: make a function from this script and check the variables in the
% workspace
%
x_vec1 = [1:100];
y_vec1 = sin(x_vec1);
figure;
plot(x_vec1, y_vec1);


x_vec2 = [1:100];
y_vec2 = rand(1,100);
figure;
plot(x_vec2, y_vec2);

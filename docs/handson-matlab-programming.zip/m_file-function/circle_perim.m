% circle_perim
% calculate the perimeter of a circle
%
% required variables: b (radius)
% result: p
p = 2 * pi * b
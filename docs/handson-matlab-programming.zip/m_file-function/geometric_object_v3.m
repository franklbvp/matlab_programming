%
% geometrical_objects_v3
% calculate the perimeter and surface of 5 geometrical objects
% use a function

clear
clc

% rectangle
b = 5
h = 3
[s1, p1] = geom_value(2, b, h)

% rectangle
b = 4.85
h = 3.69
[s2, p2] = geom_value(2, b, h)

% triangle
b = 123.3
h = 30.14
side1 = 123.3
side2 = 100
side3 = 41.1052
[s3, p3] = geom_value(4, b, h, side1, side2, side3)

% square
b = 74.5
[s4, p4] = geom_value(3, b)


% circle
b = 20 % b is radius
[s5, p5] = geom_value(1, b)

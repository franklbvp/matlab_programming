% rect_area
% calculate the area of a reactangle
%
% required variables: b, h
% result: s
s = b * h
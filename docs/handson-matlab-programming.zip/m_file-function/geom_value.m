function [surface, perimeter] = geom_value(type, dim1, dim2, side1, side2, side3)
%
%   type: number indicating the type of figure
%         1: circle
%         2: rectangle
%         3: square
%         4: triangle
%    dim1: first dimension
%         radius for a circle
%         base for a rectangle
%         base for a square
%         base for a triangle
%    dim2: second dimension
%         circle: not required
%         height for a rectangle
%         square: not required
%         heigth for a triangle
%    side1, side2, side3: 3 sides for a triangle
%

% some testing on the input
if (nargin <= 1) return
end

switch (type)
    
    case 1 % circle
        surface = pi * dim1^2;
        perimeter = 2 * pi * dim1;
        
    case 2 % rectangle
        surface = dim1 * dim2;
        perimeter = 2 * (dim1 + dim2);
        
    case 3 % square
        surface = dim1^2;
        perimeter = 4 * dim1;
        
    case 4 % triangle
        surface = 0.5 * (dim1 * dim2);
        perimeter = side1 + side2 + side3;
        
    otherwise
        fprintf('wrong type')
        surface = -1;
        perimeter = -1;
end

end


%
% geometrical_objects_v2
% calculate the perimeter and surface of 5 geometrical objects
% use scripts, the variables need to be in the workspace!

clear
clc

% rectangle
b = 5
h = 3
s = b * h % rect_area
p = 2*(b + h) % rect_perim

% rectangle
b = 4.85
h = 3.69
s = b * h % rect_area
p = 2*(b + h) % rect_perim

% triangle
b = 123.3
h = 30.14
side1 = 123.3
side2 = 100
side3 = 41.1052
s = 0.5*(b * h)% tri_area
p = side1 + side2 + side3 % tri_perim

% square
b = 74.5
s4 = b * b
p4 = 4*b

% circle
b = 20 % b is radius
s5 = pi * b^2
p5 = 2 * pi * b
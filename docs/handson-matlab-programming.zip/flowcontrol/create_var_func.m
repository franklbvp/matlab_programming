function [] = create_var_func()
% a function with the only purpose of creating some variables
% and check where these end up
var1 = 1.2
var2 = 1:10
var3 = rand(4)
end


%
% Several forms of the for-loop
%
for indi = 10:20
    fprintf('value of indi: %d\n', indi);
end
fprintf('! \n')

for indi = 10:3.3:20
    fprintf('value of indi: %6.2f\n', indi);
end
fprintf('! \n')

for indi = [11 5.5 8 17]
    fprintf('value of indi: %6.2f\n', indi);
end
fprintf('! \n')

%
% be careful when changing the index counter
%
for indi = 1:20
    %fprintf('value of indi: %d\n', indi);
    x = indi^3;
    fprintf('value of x: %8.2f\n', x)
    indi = indi - 1;
    %fprintf('value of indi: %d\n', indi);
end
fprintf('! \n')

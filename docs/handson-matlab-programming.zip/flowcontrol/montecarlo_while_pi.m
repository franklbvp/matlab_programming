%
% MonteCarlo simulation of pi
%
% throw a dart on a square board (2R * 2R)
% implemented using a while loop
% stop the iteration if the change in value of pi is below a setpoint
%
% how to get started?
%  can be a problem with a while loop, when there are transients
%  here we loop at least Nloopmin
%
clear;
clc;
close all;

setpoint = 0.01;
Nloopmin = 50000;
pi_init = 0;
pi_update = 0;

R = 1;

figure;
axis equal off;
hold on;
axis ([-R R -R R]);


rng('shuffle');  %seeding the random generator



iloop = 1;
Nthrow = 0;
Nhits= 0;
strevol = ['estimate pi = ',num2str(pi_update), ' / Nthrows = ',num2str(Nthrow)];
t = title(strevol);

while (iloop)
    
    % Throw dart
    Nthrow = Nthrow + 1;
    x = rand*R - R/2;
    y = rand*R - R/2;
    % Count it if it is in the circle
    if sqrt(x^2+y^2) <= R/2
        Nhits = Nhits + 1;
        plot(x,y,'.r');
    else
        plot(x,y,'.b');
    end
    pi_init = pi_update;
    pi_update = 4*Nhits/Nthrow;
    strevol = ['estimate pi = ',num2str(pi_update), ' / Nthrows = ',num2str(Nthrow)];
    t.String = strevol;
    drawnow;    % put this in comment to speed it up
    
    % run it at least Nloopmin times
    if (Nthrow > Nloopmin)
        if abs(pi_update - pi_init) < setpoint
            iloop = 0
        end
    end
end

fprintf('value of pi = %10.8f \n', pi_update);
fprintf('number of throws %d \n', Nthrow);

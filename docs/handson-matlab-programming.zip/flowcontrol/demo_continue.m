%
% demo_continue
%
for x=0:100
    if rem(x,2) == 0
        continue
    end
	fprintf('%d\n' , x); 
end

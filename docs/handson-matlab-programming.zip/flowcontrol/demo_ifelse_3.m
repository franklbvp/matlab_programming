%
% Purpose:
% To calculate the cost of mail a parcel.
%
% Record of revisions:
% Date Programmer Description of change
% ==== ========== =====================
% 07/13/04 S. J. Chapman Original code
%
% Define variables:
% cost -- cost in dollars
% weight -- Weight of package (lbs)
% Prompt the user for the input power.
weight = input('Enter weight of parcel, in lbs: ');
% Calculate cost
if weight > 100
% Not mailable
   disp('Packages heavier than 100 pounds cannot be mailed!');
else
   if weight <= 2
      cost = 12;
   else
      cost = 12 + (weight-2) * 4.50;
   end
% Apply penalty
   if weight > 70
      cost = cost + 15;
   end
% Display cost
   fprintf('Cost = $%.2f\n',cost);
end
function global_demo(P1)
global P
P = 13;
fprintf('In global_demo, the value of P is: %d\n', P);
fprintf('In global_demo, the value of P1 is: %d\n', P1);

%
% demo if statement: demo_if_3
%
% nested if statements
%

a = input(' enter a value for a : ');

if a > 0
    disp('a is positive')
    if (a > 10) & (a < 20)
        disp('a is in between 10 and 20')
        if (a == 15)
            disp('a equals 15');
        end
    end
end

disp('this is the next line');

%
% calculate sum of 1 up to 100
%
% do it with a while loop

sum100 = 0;

i = 1;
while (i <=100)
    sum100 = sum100 + i;
    i = i + 1;
end

disp('sum100 = ');
disp(sum100)

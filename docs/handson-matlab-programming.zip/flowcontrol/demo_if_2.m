%
% demo if statement: demo_if_2
%
%
x = [ 1 2 3 4];
y = [ 1 2 3 NaN];
z = x;


if (x == y)
    disp ('all elements of x are equal to those of y');
end

if (x == z)
    disp ('all elements of x are equal to those of z');
end

ltest = (x == z);
if ltest
    disp ('all elements of x are equal to those of z');
end

if all(x == y)
    disp ('all elements of x are equal to those of y');
end

if any(x == y)
    disp ('some elements of x are equal to those of y');
end

%
% FOR - example
% + nesting
%
for indi = 1:4
    for indj = 1:3
        c(indi,indj) = 2*indi + 3*indj;
    end
end
c

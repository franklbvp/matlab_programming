%
% example if else
%


if isempty(who)
    % this useful
   disp('Empty workspace')
else
   who
end
function localvar
global P

P = 99;
P1 = 12;
fprintf('In localvar, the value of P is: %d\n', P);
fprintf('In localvar, the value of P1 is: %d\n', P1);
%fprintf('In localvar, the value of a (in base workspace) is: %d\n', a);

%
% compute factorial
%
function f=func_fact(n)
if n==1 
    f=1; 
else
    f=n*func_fact(n-1);
end;

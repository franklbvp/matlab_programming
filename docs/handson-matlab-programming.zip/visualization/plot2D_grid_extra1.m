%
% example grid extra 1
%
clear
close all

x = 0.01:0.002:pi/2;
y=sin(1./x)./x;

subplot(1,2,1)
plot(x,y), grid

subplot(1,2,2)
plot(x,y), grid

xt = [0 0.05 0.1 0.2 0.4 0.6 1.  pi/2];
xl = {'', '', '0.1', '', '', '0.6', '1', 'pi/2'}
set (gca, 'XTick', xt, 'XTicklabel', xl) 
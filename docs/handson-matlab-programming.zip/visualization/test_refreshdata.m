%
% refresh the data
%
x = 0:.1:8*pi;
y = sin(x);
h = plot(x,y)
set(h,'XDataSource','x');
set(h,'YDataSource','y');
y = sin(x.^3);
refreshdata

%
% example contour
%
[x, y] = meshgrid(-2:.1:2, -1:.1:1);
z = x.* exp(-x.^2-y.^2);

[c,h] = contour(x, y, z);
clabel(c,h);
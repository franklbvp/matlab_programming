%
% plotmatrix
%
close all
clear all

% generate data
x = randn(1000, 1);
A=[x, sin(x), cos(x)];
plotmatrix(A);
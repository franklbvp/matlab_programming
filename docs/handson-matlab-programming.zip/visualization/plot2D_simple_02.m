%
% Example: line plot with  matrix data
%           data are considered to be in columns
%
y=rand(100, 5);
%
plot(y);                        % plot command
ylabel('random');                 % set the y label
legend ('rand1', 'rand2', 'rand3', 'rand4', 'rand5') ;


% 
% another 3D demo
%
close all
clear

%
% The primary method of using MATLAB to create the plot of a three-dimensional surface 
% is the surf  command which is used in conjunction with the meshgrid command. 
% Meshgrid creates a matrix of (x , y) points over which the surface is to be plotted. 
% For example

    [x,y]=meshgrid(-2:1:2,-2:1:2)

% creates two matrices x and y that form 25 points, 
% by using each value in matrix x with the value in the corresponding position in matrix y.

% The surf command can then be used to draw the surface z =x 2? y2

    surf(x,y,x.^2-y.^2)


% Note that this gives a surface plotted at 25 data points. 
% To smooth out the surface, add more points to the meshgrid command. 
% You can suppress the output of the matrix by adding a semicolon to the end of the meshgrid command.

    [x,y]=meshgrid(-2:0.1:2,-2:0.1:2);

    surf(x,y,x.^2-y.^2)


% One feature of MATLAB is the colorbar command, 
% which gives a vertical bar indicating the height represented by each color on the surface.

    colorbar


% The EdgeColor command can be used to remove the gridlines.

    surf(x,y,x.^2-y.^2,'EdgeColor','none')


% The shading interp (for interpolated) command can be used to further smooth the surface. 
% A single rectangular piece of the surface gradually changes color.

    shading interp


% The surfc command also creates a surface but adds a contour plot in the xy plane.

    surfc(x,y,x.^2-y.^2,'EdgeColor','none')

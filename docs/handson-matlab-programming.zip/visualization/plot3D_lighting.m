%
% example surf & lighting
%
clear
clc
close all


subplot (2, 2, 1)
sphere;
light;
shading interp;
axis square;
axis off;
lighting none
title ('no effects')

subplot (2, 2, 2)
sphere;
light;
shading interp;
axis square;
axis off;
lighting flat
title ('flat')


subplot (2, 2, 3)
sphere;
light;
shading interp;
axis square;
axis off;
lighting phong
title ('phong')


subplot (2, 2, 4)
sphere;
light;
shading interp;
axis square;
axis off;
lighting gouraud
title ('gouraud')


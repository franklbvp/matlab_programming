%
% more basic examples on the plot command
%

close all
clear

%X is a matrix argument to plot
% the data are plotted as index number (1, 2, 3...) vs column 
X=[1 2 3; 4 5 6; 7 8 9];
plot(X);

%x is a vector and is the first argument to
%plot, and Y is a matrix and is the second argument to plot
x=[2 4 6 8 10];
Y=[3 5 7 9 11; 4 8 12 16 20];
plot(x,Y,'*');

%x is a vector and is the second argument to
%plot, and Y is a matrix and is the first argument to plot 
plot(Y,x,'o');

%both X and Y are matrices and are arguments to plot.
%data is plotted columnwise
X=[1 2 3; 4 5 6; 7 8 9];
Y=[2 4 6; 16 25 36; 10 11 12];
plot(X,Y);

X=[2 4 6 8 10; 1 3 5 7 9];
Y=[3 5 7 9 11; 4 8 12 16 20];
plot(X,Y,'*');

%
% example text extra 1
%
clear
close all

% generate data

xd = rand(1, 10)/10 + 0.01;
yd = rand(1, 10)/10 + 0.015;
datastr = ['10.01'; '17.01'; '24.01';...
           '31.01'; '07.02'; '14.02';...
           '21.02'; '28.02'; '07.03';'14.03'];
       
plot(xd, yd, 'o');
text(xd, yd, datastr, 'fontsize', 10, 'verticalalignment', 'bottom');

xlabel('data A');
ylabel('data B');

xmin=min([xd yd]);
xmax=max([xd yd]);
xp = linspace(xmin, xmax);
hold on 
plot(xp, xp)
hold off

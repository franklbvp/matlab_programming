%
% error bars plot using exportfig!
%
% https://icme.hpc.msstate.edu/mediawiki/index.php/Errorbars_Plot
%%
x = 0.01:0.01:1;
y = log(x); y = y - y(1);
err_lo = x.*(1+rand(size(x)))/2;
err_hi = x.*(1+rand(size(x)))/2;

%%
% Plot this if you want to see the band of low, high, and mean behavior
plot(x,y,'.r'), hold on
plot(x,y-err_lo,'.b')
plot(x,y+err_hi,'.k')
close(1)

%%
% Journal quality plot
plot(x,y,'-dr','LineWidth',2,'MarkerSize',3,'MarkerFaceColor','r'), hold on
% Use this to select errorbars every 10 datapoints
n = 1:10:100;  
% ... or do this for only specific data points
n = [25, 35, 75, 85 90];  
errorbar(x(n),y(n),err_lo(n),err_hi(n),'or','MarkerSize',5,'MarkerFaceColor','r','LineWidth',2)
symbol = 'or';
head_width = 25;
hh = herrorbar(x(n),y(n),err_lo(n)/6,err_hi(n)/6,head_width,symbol);
set(hh,'LineWidth',2)

axis square
ylim([0 6]), xlim([0 1])
set(gca,'LineWidth',2,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','Strain, \epsilon','FontSize',32,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','Stress, \sigma (MPa)','FontSize',32,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 1000 1000])

exportfig(gcf,'plot1_pro.jpg','Format','jpeg','Color','rgb','Resolution',300)
exportfig(gcf,'plot1_pro.eps','Format','eps','Color','rgb','Resolution',300)
close(1)

%
% easy plotting demo
%
subplot (2, 2, 1)
fplot(@humps, [-.5 3])
title('fplot - humps function')
xlabel('x')
ylabel('humps(x)')

subplot (2, 2, 2)
f_hdl = @(x) sin(x)/x;
ezplot(f_hdl, [-15 15])
title('ezplot - sinx/x')
xlabel('x')
ylabel('sin(x)/x')

subplot (2, 2, 3)
istr = '(x-2)^2/4 + (y+1)^2/9 -1';
ezplot(istr, [-2 6  -5 3])
title('ezplot - istr')
axis square
xlabel('x')
ylabel('y')

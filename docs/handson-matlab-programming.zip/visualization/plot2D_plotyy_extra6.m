x = 0:0.01:20;

y1 = 200*exp(-0.05*x).*cos(x);
y2 = 0.8*exp(-0.5*x).*cos(10*x);

[AX,H1,H2] = plotyy(x,y1,x,y2,'plot');
axis('square');
axis([AX(1) AX(2)],'square');
%
% plot3D_overview
%
% overview of basic 3D plotting in matlab
% based on http://www.stewart.cs.sdsu.edu/cs205/module9/3Dgraphics.html
%
x = [0: pi/4: 6*pi];
y = [-pi/2: pi/16: pi/2];
z = y' * cos(x);
%
% remark:
% y' is used in the expression to generate z-data
% meshgrid could generate the same result
%
%    x = [0: pi/4: 6*pi];
%    y = [-pi/2: pi/16: pi/2];
%    [ X, Y ] =  meshgrid(x,y) ; 
%    z  =  Y.* cos(X);

mesh(z)
title('Mesh Surface: f(x,y) = y cos(x)')
%
%create a matrix of (X,Y) from vector

figure
[X,Y] = meshgrid(-8:.5:8); 
R = sqrt(X.^2 + Y.^2) + eps; % sinc function sin(r)/r
Z = sin(R)./R;
mesh(X,Y,Z)
figure
mesh(x,y,z)
title('Mesh Surface: f(x,y) = y cos(x)')
xlabel('x'),ylabel('y'),zlabel('z')
figure
surf(z)
title('Shade Surface: f(x,y) = y cos(x)')
figure
contour(z)
title('Contour: f(x,y) = y cos(x)')
xlabel('x'), ylabel('y')
figure
meshc(z)
title('Mesh Surface with Contour: f(x,y) = y cos(x)')
xlabel('x'), ylabel('y'), zlabel('z')

[x,y,z] = peaks % predefined data set
contour (x,y,z,20,'k')
hold on
pcolor(x,y,z) % pseudocolor (checkerboard) plot
shading interp % default value is "faceted"
rotate3d on % your mouse can change azimuth and elevation - patience
figure
[c,h] = contour(peaks), clabel(c,h), colorbar % get picture with contours labeled and a color bar
figure
[x,y,z] = peaks % predefined data set
mesh(x,y,z)
view(-37.5,30)
view(0,0)
view(-90,0)
view(-37.5,10)
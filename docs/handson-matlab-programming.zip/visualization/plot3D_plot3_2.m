%
% example plot3
%

t = linspace(0, 10*pi, 500);
plot3(sin(t), cos(t), t, 'o-');


% if the arguments to plot3 are matrices of the same size, 
% MATLAB plots lines obtained from the columns of X, Y, and Z. 

[X,Y] = meshgrid([-2:0.1:2]);
Z = X.*exp(-X.^2-Y.^2);
figure
plot3(X(:,1),Y(:,1),Z(:,1))
figure
plot3(X,Y,Z)
grid on

%
% plotyy extra
% How can I draw more than two lines with plotyy?
%
close all
clear

% You can use the axes' handles to plot additional lines, as follows:

% generate data
x1 = (1:10)';  
x2 = x1;  
y1 = x1; 
y2 = x1.^2;

%Plot one line against each of the left and right y-axis
[ax, h1, h2] = plotyy(x1,y1,x2,y2);

%Plot additional line against the left y-axis
x3= x1;  y3 = y1 + 3;
h3 = line(x3,y3,'Parent', ax(1), 'Color',get(h1,'Color'));

%Plot additional line against the right y-axis
x4= x1;  y4 = y2+3;
h4 = line(x4,y4,'Parent', ax(2), 'Color',get(h2,'Color'));
set(ax,'YLimMode','auto','YTickMode','auto')
 
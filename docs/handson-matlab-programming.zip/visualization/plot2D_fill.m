%
% demo on filling a polygon
%
x1=sqrt(2)/2; y1=0;
x5=sqrt(2); y5=sqrt(2)/2;
m1=(y5-y1)/(x5-x1);
y2=sqrt(2)/6;
x2=x1+(y2-y1)/m1;
y4=sqrt(2)/3;
x4=x1+(y4-y1)/m1;
x3=x5;y3=y2;
x6=x2;y6=y5;
x7=x1;
y7=2*sqrt(2)/3;
x8=x7-(x6-x7);
y8=y6;
x9=0; y9=y8;
x10=x1-(x4-x1);
y10=y4;
x11=0;y11=y3;
x12=x8;y12=y11;
x=[x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x1];
y=[y1 y2 y3 y4 y5 y6 y7 y8 y9 y10 y11 y12 y1];
axis equal
fill(x,y,'r')
%
% meshc / meshz example using the peaks function
%
[x,y,z]=peaks(30);
meshc(x,y,z)
axis tight
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')

figure
meshz(x,y,z)
hidden off
axis tight
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')

figure
waterfall(x,y,z)
hidden on
axis tight
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
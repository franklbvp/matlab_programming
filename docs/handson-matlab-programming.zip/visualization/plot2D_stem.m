%
% example stem
%

alpha = .02; beta = .5; t = 0:4:200;
y = exp(-alpha*t).*cos(beta*t.^2);


plot(t,y);

figure;
stem(t,y);
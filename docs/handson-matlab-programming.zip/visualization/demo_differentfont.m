% 
% use different font in matlab figure
%

clear
close all

x = -pi:.1:pi;
y = sin(x);

figure;
subplot(1,3,1)
plot(x,y)
title(['Sine Wave'],'interpreter','latex')
xlabel(['x'],'interpreter','latex', 'FontSize', 15)
ylabel(['y'],'interpreter','latex', 'FontSize', 15)
text(-3.5, 0.8,'y = sin(x)', 'interpreter', 'latex', 'FontSize', 15)


subplot(1,3,2)
plot(x,y)
title(['Sine Wave'])
xlabel(['x'],'FontSize', 15)
ylabel(['y'],'FontSize', 15)
text(-3.5, 0.8,'y = sin(x)', 'FontSize', 15)


subplot(1,3,3)
plot(x,y)
title(['Sine Wave'],'FontName', 'Impact')
xlabel(['x'],'FontName', 'Impact','FontSize', 15)
ylabel(['y'],'FontName', 'Impact','FontSize', 15)
text(-3.5, 0.8,'y = sin(x)', 'FontName', 'Impact','FontSize', 15)

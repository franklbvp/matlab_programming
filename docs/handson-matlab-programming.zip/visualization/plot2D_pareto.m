%
% pareto plot
%
close all
clear

% generate data

xpar = rand(1,12);

% corresponding labels
xlab ={'Jan'; 'Feb'; 'Mar'; 'Apr'; 'May'; 'Jun';...
    'Jul'; 'Aug'; 'Sep'; 'Oct'; 'Nov'; 'Dec'};

pareto(xpar, xlab);
grid on

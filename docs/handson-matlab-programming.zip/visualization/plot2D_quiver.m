%
% example quiver
%
[x, y] = meshgrid(-2:.2:2, -1:.1:1);
z = x.* exp(-x.^2-y.^2);

%
%
%
[dx, dy] = gradient(z, .2, .15);

contour(x, y ,z)
hold on;
quiver(x, y, dx, dy);
hold off;
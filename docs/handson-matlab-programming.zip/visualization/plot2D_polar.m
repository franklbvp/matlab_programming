%
% Example: polar plot
%
phi = linspace(0, 2*pi);
r = linspace(0, 1);
%
polar(phi, r);


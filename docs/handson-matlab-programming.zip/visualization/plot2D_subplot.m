%
% Example: multiple plots
%
x = linspace(0,2*pi);
y = [sin(x); cos(x)];
%
% subplot(m,n,p): creates an axes in the p-th pane of a figure divided into an m-by-n 
%                   The new axes becomes the current axes. 
%

subplot(2,1,1); plot(y);
ylabel('2*100');
title('subplot 1');

subplot(2,1,2); plot(y');
ylabel('100*2');    
title('subplot 2');



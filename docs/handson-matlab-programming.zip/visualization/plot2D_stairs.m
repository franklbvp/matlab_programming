%
% Example: stairs plot
% 
close all;
clear

Y = rand(1,10)

stairs(Y)

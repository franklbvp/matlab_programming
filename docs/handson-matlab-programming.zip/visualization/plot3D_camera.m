subplot(2,1,1) % global view
membrane % logo of MATLAB

hold on
xlabel('x'); ylabel('y'); zlabel('z'); % useful for positioning

s = [-0.9 1.0 0.2]; % start position
plot3(s(1),s(2),s(3),'r+'); % mark start on plot

p = [0.5 0.0 1.1]; % peak of membrane
plot3(p(1),p(2),p(3),'bx'); % mark peak on plot

subplot(2,1,2) % create local view
membrane
hold on
set(gca,'CameraPosition',s) % place the camera
set(gca,'CameraTarget',p) % aim the camera
set(gca,'Projection','Perspective') % perspective view
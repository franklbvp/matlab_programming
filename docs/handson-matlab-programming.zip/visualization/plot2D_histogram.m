%
% matlab demo hist
% where x is a vector, returns the distribution of Y among length(x) bins
% with centers specified by x. For example, if x is a 5-element vector, 
% hist distributes the elements of Y into five bins centered on the x-axis at the elements in x


x = -2.9:0.1:2.9;
y = randn(10000,1);
hist(y,x);

%
% play around with the handles to change the properties
%
h = findobj(gca,'Type','patch');
set(h,'FaceColor','r','EdgeColor','w')

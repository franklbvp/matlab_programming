%
% Example: bar plot
% 
Y = rand(10,3)

subplot(2,2,1)
bar(Y,'group')
title 'Group'

subplot(2,2,2) 
bar(Y,'stack')
title 'Stack'

subplot(2,2,3)
barh(Y,'stack')
title 'Stack'

subplot(2,2,4)
bar(Y,2)
title 'Width = 2'
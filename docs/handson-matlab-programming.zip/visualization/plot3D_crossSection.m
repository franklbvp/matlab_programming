%
% making a cross section of your data
% 
% by Marco De la Cruz-Heredia

% It would be nice to see what a cross-section of the plot looks like! It's a good idea, though, to first mark where I'm making the cross-section (two, in this case):

clear
close all

% Make the contour plot
pcolor(peaks)
shading flat

colormap(1 - 0.7*hot)


xlabel('x')
ylabel('y','Rotation',0,'FontSize',16)

% labeling

hold on
ContourHandle = contour(peaks,'b--');
clabel(ContourHandle,'FontSize',15,'Color','r','Rotation',0)


hold on

cutx = 20;
cuty = 10;
peakdata = peaks;
plot(cutx*ones(1,length(peakdata)),[1:length(peakdata)],'y')
plot([1:length(peakdata)],cuty*ones(1,length(peakdata)),'r')

% OK, now it's time to make the plot. First we have to tell MATLAB where we want the new set of axes and the size of the area they must occupy:

RightAxesHandle = axes('Position',[.855 .1 .12 .8]);

% Tip: if all your plots are of the same size you can use the command "subplot" and be done with it! Another thing is that you can break lines in MATLAB using three dots (...) as shown below.
% Let's plot the cuts! (But not cut the plots! OK, OK - that was lame ^_^;)
	

[RightAxesHandle, CutXHandle, CutYHandle] = ...
plotyy(peakdata(:,cutx),[1:length(peakdata)], ...
peakdata(cuty,:),[1:length(peakdata)]);

set(CutXHandle,'Color','y')
set(CutYHandle,'Color','r')
set(RightAxesHandle(1),'YTick',[],'YTickLabel',[],'YColor','y')
set(RightAxesHandle(2),'YTick',[10 30 40],'YTickLabel', ...
['a'; 'b'; 'c'],'YColor','r')
set(RightAxesHandle(1),'XTick',[],'XTickLabel',[])
set(RightAxesHandle(2),'XTick',[],'XTickLabel',[])

title('\Gamma_0')


% The "plotyy" command simply draws a red line where the cut along x is made, while the yellow line indicates the cut along y. Note that two vertical axes are created (that's why it's called "plotyy", duh!). The "set" commands just change the settings of the axes a bit so that they look cool. Note that (La)TeX notation can be used to adds symbols and simple equations anywhere in the figures! (Try "help text" for more info on that).


% addd a 3rd set of graphics and a surface plot
PeaksPlotHandle = axes('Position',[.1 .65 .25 .25],'Visible','off');

surf(peaks)
shading flat

set(PeaksPlotHandle,'Box','on')
set(PeaksPlotHandle,'XTick',[])
set(PeaksPlotHandle,'XTickLabel',[])
set(PeaksPlotHandle,'YTick',[])
set(PeaksPlotHandle,'YTickLabel',[])
set(PeaksPlotHandle,'ZTick',[])
set(PeaksPlotHandle,'ZTickLabel',[])
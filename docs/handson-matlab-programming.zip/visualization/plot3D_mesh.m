%
% example mesh
%
close all
clear all

[x, y] = meshgrid(-2:.1:2, -1:.1:1);
z = x .* exp(-x.^2-y.^2);

mesh(x,y,z);
%mesh(z)
%rotate3d;

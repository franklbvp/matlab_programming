%
% Example: multiple plots
%
x = linspace(0,2*pi);
y = [sin(x); cos(x)];
%
plot(y)

plot(y')
%
%http://www-ccs.ucsd.edu/~blesh/how_to_make_animations.html
%
% this line turns the visibility off (of the intermediate steps)
%
hfig = figure('visible', 'off')

% Create a sphere matrix
%
[x,y,z] = sphere(179);

%
% load matlab topography database
% (included in demo)
%
load topo;
c = topo(1:180,1:2:360);

%
% plot a globe with topography
%
surf(x,y,z,c);
axis off;
shading('interp')

%
%  rotate every 2 degrees and rotate through 60 degrees 
%
rot_ang = 2;
rot_deg = 120;

%
% allocate matrix Frames for storing  movie frames
% (=initialize the matrix 'Frames')
%
nframes = 60;              
Frames = moviein(nframes); 


index = 0;

%
% Start at -120 degrees longitude
%
for ii = -120:rot_ang:(-120+rot_deg)
    index = index + 1;
%
% change the view angle by 2 degrees on each of these to make each frame
%
    view([ii 14]);
%
% the axis('vis3d') command keeps the axis the same through rotation
%
    axis('vis3d');

% 
% each frame can be saved in a separate file (files can be postprocessed in another program)
% the filename looks like cor.00001.jpg 
%
%%	filename = sprintf('cor.%.5d.jpg',index);

%
% the next two commands create a file from the current figure
%  
%%	[X,map] = capture;  % capture captures the current figure in  Matlab
%%    imwrite(X,map,filename,'jpg'); % imwrite writes a file that looks exactly as the figure
%

%
% save the frame in the movie matrix
%
    Frames(:,index)=getframe;

end

pause(5);
%
% movie data
%
% reruns: number of times movie is to play
% fps: frames per second

reruns=1;                  
fps=5;                   

%
% play the movie: 
%
movie(Frames,reruns,fps)


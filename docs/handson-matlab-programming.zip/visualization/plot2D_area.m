%
% Example: area plot
% An area plot displays elements in Y as one or more curves 
% and fills the area beneath each curve. 
% When Y is a matrix, the curves are stacked showing 
% the relative contribution of each row element to 
% the total height of the curve at each x interval.


x=0:.4:2*pi;
y1=sin(x);
y2=sin(x)/2;
plot(x',[y1' y2']);
figure;
area(x',[y1' y2']);
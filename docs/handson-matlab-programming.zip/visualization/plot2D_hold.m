%
t = 0:1:12;
a = 1;
b = 2;

f=(exp(-a*t)-exp(-b*t))/(b-a);
plot(t,f,'r-.')

hold on

a = 3;
b = 5;

f=(exp(-a*t)-exp(-b*t))/(b-a);
plot(t,f,'b--')

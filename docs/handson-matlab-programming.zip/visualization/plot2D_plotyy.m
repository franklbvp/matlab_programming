%
% plotyy
%
close all
clear

x = 0:0.1:2*pi;
y1 = sin (x);
y2 = exp (x);
[ax, h1, h2] = plotyy (x, y1, x, y2, @plot, @semilogy);
set(h1,'LineStyle','-') 
set(h2,'LineStyle','--')
legend([h1, h2], 'y1', 'y2')
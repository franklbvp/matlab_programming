%
% moving sine wave
%
% http://instruct1.cit.cornell.edu/courses/bionb441/ImageUse/
%


close all
clear all
set(gcf,'doublebuffer','on');

%Build the grid which determines the image resolution
[x,y] = meshgrid(1:256,1:128);

%initialize the movie
n=40;
mov=moviein(n);

%build the frames
speed=.05;freq=.2;
for i=1:n
   %the frame is just a sinewave grating
   %intensity modulated to--to-botton
   img=128 * (sin(x*freq+speed*i)+1) .* y.^2/128^2;
   image(img);
   %add a frame number
   text(10,10,num2str(i),'color','white')
   %Force real pixels
   truesize(gcf)
   %transfer the image to a movie frame
   mov(i)=getframe; 
end

%clear the image
image(0*x);axis image;
pause(1);
%playback the movie 
%--five times, with reversal
%--at 30 frames/sec
movie(mov,-5,30);
image(0*x);axis image;

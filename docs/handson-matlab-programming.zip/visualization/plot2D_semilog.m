%
% Example: semilogy plot
% 
% semilogx(Y) creates a plot using a base 10 logarithmic scale for the x-axis 
% and a linear scale for the y-axis. 
% It plots the columns of Y versus their index if Y contains real numbers. 
%
x = linspace(1, 10);
y = exp(x);
%
semilogy(x, y, 'b-.');


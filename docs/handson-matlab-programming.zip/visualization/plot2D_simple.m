%
% Example: line plot
%
x=0:0.05:5;
y=sin(x.^2);
%
plot(x,y);                  % plot command
xlabel('x')                 % set the x label
ylabel('y')                 % set the y label
title('This is a plot')     % title
%grid                        % set a grid
print('sinPlot1_print','-dpng')
saveas(gcf,'sinPlot1_saveas','png')

%pause
plot(x,y,'--rs')
print('sinPlot2_print','-dpng')
saveas(gcf,'sinPlot2_saveas','png')

%pause
plot(x,y,'--rs','LineWidth',2,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor','g',...
                'MarkerSize',10)
            
print('sinPlot3_print','-dpng')
saveas(gcf,'sinPlot3_saveas','png')

            
%pause
plot(x,y,'ws',...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor','g',...
                'MarkerSize',10)
leg1 = legend('Data');
set(leg1,'EdgeColor',[1 1 1]);
print('sinPlot4_print','-dpng')
saveas(gcf,'sinPlot4_saveas','png')
print('sinPlot4_print','-dpdf')
saveas(gcf,'sinPlot4_saveas','pdf')

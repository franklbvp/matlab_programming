clf
peaks
colorbar
m = colormap;
whos m
colormap(autumn)
brighten(0.5)
colormap(jet)
colormap(bone)
colormap(hot)
%
% test various ways to export graphics
%

% draw cos
plot(cos(linspace(0, 7, 1000)));

% set dimensions of figure
set(gcf, 'Position', [100 100 150 150])

% default saveas
saveas(gcf, 'test_saveas.png')

% use export_fig
export_fig('test_export_fig.png')
%
% subplot extra example 1
%

%y = logspace(a,b,n) generates n points between decades 10^a and 10^b
%
x = logspace(-2,2,500);

y = exp(-x.^2/10);
subplot(2,2,1);
plot(x,y);
title('plot');

subplot(2,2,2);
loglog(x,y);
title('loglog');

subplot(2,2,[3 4]);
semilogx(x,y);
title('semilog');
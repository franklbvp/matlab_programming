close all
clear all

initValues=rand(50);

a=[0 50 0 50 0 20];

surf(initValues), shading interp, axis(a)
axis off;

m(1)=getframe;

for i=2:100

     initValues=initValues+rand(50)*.25;

     surf(initValues), shading interp, axis(a)
     axis off;
     m(i)=getframe;

end

 
movie(m)
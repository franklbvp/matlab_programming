%
% To dock figures by default, try calling:
% http://stackoverflow.com/questions/6911176/have-matlab-figures-docked-by-default

set(0,'DefaultFigureWindowStyle','docked')

% set it back to normal
%set(0,'DefaultFigureWindowStyle','normal')
%
% demo 
%

[xx yy zz] = sphere;
s = surf(xx,yy,zz);
set(s, 'EdgeColor','r','FaceColor','none'); 
axis off; 
set(gca,'DataAspectRatio',[1 1 1]);
light; 
set(s,'LineWidth',6) 
hold on;
[xx yy zz] = sphere;
s2=surf(xx/2,yy/2,zz/2);
set(s2,'CData',rand(21),'FaceColor','interp')
colormap(cool(100))
lighting phong;      
set(gca,'CameraViewAngle',7);
set(gcf,'color',[1 1 1]);

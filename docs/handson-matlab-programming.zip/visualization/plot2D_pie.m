%
% example pie chart
%
x = rand(1, 5);
explode = x./ sum(x) < .20;
pie(x,explode)

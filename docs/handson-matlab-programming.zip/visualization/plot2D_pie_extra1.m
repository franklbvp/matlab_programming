%
% pie chart extra 1
%
clear all
close all


val = [12   17   21];
explode = [0   0   1];
h = pie(val, explode);
colormap summer
textObjs = findobj(h, 'Type', 'text');
newStr = {'X'; 'Y'; 'Z'};
set(textObjs, {'String'}, newStr)

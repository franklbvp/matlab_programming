
%
% visualize (x,y,z) data (nonuniformly distributed)
% based on http://nl.mathworks.com/help/matlab/visualize/representing-a-matrix-as-a-surface.html

% grid point in x-y plane
x = rand(100,1)*16 - 8;
y = rand(100,1)*16 - 8;

% function value
r = sqrt(x.^2 + y.^2) + eps;
z = sin(r)./r;


% The linspace function provides a convenient way to create uniformly spaced data with the desired number of elements. 
xlin = linspace(min(x),max(x),33);
ylin = linspace(min(y),max(y),33);
% use these points to generate a uniformly spaced grid:
[X,Y] = meshgrid(xlin,ylin);


% use scatteredInterpolant to interpolate the values of the function at the uniformly spaced points, 
% based on the values of the function at the original data points 
f = scatteredInterpolant(x,y,z);
Z = f(X,Y);

% Plot the interpolated and the nonuniform data to produce:
figure
mesh(X,Y,Z) %interpolated
axis tight; hold on
plot3(x,y,z,'.','MarkerSize',15) %nonuniform

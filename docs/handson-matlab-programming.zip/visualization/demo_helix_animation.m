% IAP 2006 Introduction to MATLAB
% Graphics

% EXAMPLE  Helix Animation
% A Helix is a 3D curve, described by coordinates:
% x = a*cos(t); y = a*sin(t); z = b*t

% A. Create an animated plot in the Figure Window

% A1. Set the attribute DoubleBuffer of the current figure to On
% so that the plot does not flicker during animation.
set(gcf, 'DoubleBuffer', 'on')

% A2. Define the range of t, and the coefficients a and b.
t = [0 : 0.02*pi : 6*pi];
a = 2; b = 1;

% A3. Draw the Helix in 3D, redrawing the plot after adding every point.
set(gcf, 'Name', 'Helix Animation')

for i=1:length(t)
    
   plot3(a*cos(t(i)), a*sin(t(i)), b*t(i), 'ro');
   hold on
   % Set the axes to be the same during plotting
   set(gca, 'XLim', [-2 2], 'YLim', [-2 2], 'ZLim', [0 20])
   drawnow
   
   % Save the frame in a matrix M to play later - see part B.
   M(i) = getframe(gcf);
   
end
hold off


%  Play the animation saved in M in MATLAB
% Try the command below (uncommented) in the Command Window:
% movie(gcf, M, 1, 30)
% The animation in the Figure window plays once at 30 frames per second.

% B. Save the animation to play outside of MATLAB

movie2avi(M, 'helix.avi', 'fps', 30, 'quality', 100);


%
% axis examples
%
x = 0:.025:pi/2;
plot(x,tan(x));

axis([0  pi/2  0  5]);

axis off;

axis on;

axis equal;

axis square;

axis tight;

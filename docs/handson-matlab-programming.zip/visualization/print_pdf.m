%
%
clear;
clc;
close all;
%
surf(peaks(30));
% export as pdf
saveas(gcf,'surf_saveas.pdf')
print -painters -dpdf -r600 surf_print.pdf

% export as jpg
saveas(gcf,'surf_saveas.jpg')
print -painters -djpeg -r600 surf_print.jpg
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   Ein paar kleine Matlab - Spielereien  
%
%   3D-Plots mit surf
%   http://www-user.tu-chemnitz.de/~uro/teaching/matlab/surftest.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear


% Dargestellt werden sollen in einer Matrix gespeicherte Funktionswerte
% einer Funktion f: Omega \in R^2 -> R^1

% Zeilen- und Spaltenanzahl der Diskretisierung
m=40
n=50 

% Argumente als diskrete Werte aus Omega
X=[];
Y=[];


fprintf('Generating X and Y ...\n');
for i=0:m-1
  Y(i+1)= i * 1.0 / (m-1);
end

for j=0:n-1
  X(j+1)= j * 1.0 / (n-1);
end




% Die Funktionswerte bestimmen

fprintf('Generating A ...\n');
A=[];
for i=1:m
  for j=1:n
   A(i,j)= 1- X(j) -  Y(i) -  X(j) * sin ( 10* Y(i) ) ;
  end
end




fprintf('Plotting ...\n');

titlename='Testplot ... ';

% Darstellen
surf(X,Y,A);

% Achsenbreich festlegen 
% xmin,xmax,ymin,ymax,zmin,zmax
axis([ 0,1,0,1,-1.9 ,1.3 ] )  

% Explizites festlegen von Tics und Ticlabels
set(gca,'XTick',[0,1])
%set(gca,'XTickLabel',{'0','1.0'})
  
set(gca,'YTick',[0,1])
set(gca,'YTickLabel',{'a','b'})

% Blickwinkel  
view(117,16)

% Mit oder ohne Grid
grid on;
%grid off;

% Box um das ganze Bild
set(gca,'box','on');


% Achsenlabel
xlabel('xxx'); 
ylabel('yyy');

% Titel
set(gca,'Fontsize',14,'Fontname','Times')
title(titlename,'Fontsize',24,'Fontname','Times');


%  Eine beliebige Colormap aussuchen

%colormap hsv
%colormap autumn
%colormap cool
%colormap copper
colormap jet
%colormap summer
%colormap pink
%colormap hot
%colormap prism
%colormap spring


% Angeben ob mit oder ohne Grid, 
% interpoliert oder wie man es gern haette

%shading flat
shading faceted
%shading interp




% Bild als Postscript abspeichern
psname='surftest.ps';
figure(1)
fprintf('Printing Postscript %s ... \n',psname);
%orient portrait
orient landscape
print ('-dpsc',psname);


fprintf('All Done\n\n');
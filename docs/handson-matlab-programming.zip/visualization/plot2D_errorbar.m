y1 = rand(10,1);                      % create a random vector (10 x 1) from 0 to 1
y2 = linspace(1,0,10);                % create a vector of numbers from 10 to 1
x = 1:10;                             % create a vector of integers from 1 to 10
plot(x,y1,'b+',x,y2,'r-');

title('Test of plot function');       % make a title
xlabel('X Axis');                     % label the axes

figure;
errorbar(x,y1,ones(10,1).*0.1)    
axis([0 10 0 1]);
title('Test of errorbar');
xlabel('X axis'); ylabel('Y axis');
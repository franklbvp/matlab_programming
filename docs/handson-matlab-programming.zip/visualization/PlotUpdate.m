function PlotUpdate()   
    x = 0:.1:8;
    y = sin(x);
    h = plot(x,y);
% change the data
    y = sin(x.^3);
% update the plot?   
    set(h,'XData',x,'YData',y);
end
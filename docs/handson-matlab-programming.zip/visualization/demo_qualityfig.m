clear;
clc;
close all;

% Demonstration code on creating and exporting quality figures with matlab
% 
% based on
% http://www.gatsby.ucl.ac.uk/~turner/TeaTalks/matlabFigs/matlabFig.pdf

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Toy data

t = linspace(0,20,1000);
s1 = sin(t+pi/3);
s2 = sin(t);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Version 1: Basic plot

figure

subplot(1,2,1)
plot(t,s1,'-')
ylabel('y')
xlabel('\omega = 2 \pi c/\lambda')

subplot(1,2,2)
plot(t,s2,'-')
xlabel('\omega = 2 \pi c/\lambda')

% This can now be exported by hand using the matlab figure menu
% use 'save as' - use jpg and tif format, check the resulting file with a
% viewer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Version 2: Automating exporting using print

figure

subplot(1,2,1)
plot(t,s1,'-')
ylabel('y')
xlabel('\omega = 2 \pi c/\lambda')

subplot(1,2,2)
plot(t,s2,'-')
xlabel('\omega = 2 \pi c/\lambda')

filename = 'demo_qualityfig_2.jpg';
print(gcf,'-djpeg',filename);

filename = 'demo_qualityfig_2.tif';
print(gcf,'-dtiff',filename);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Version 3: Automating exporting using export_fig (matlab central)

figure

subplot(1,2,1)
plot(t,s1,'-')
ylabel('y')
xlabel('\omega = 2 \pi c/\lambda')

subplot(1,2,2)
plot(t,s2,'-')
xlabel('\omega = 2 \pi c/\lambda')

% set(gcf, 'Color', 'white'); % white bckgr   (if a white background is
% neede)
export_fig( gcf, ...        % figure handle
    'demo_qualityfig_3',... % name of output file without extension
    '-painters', ...        % renderer
    '-jpg', ...             % file format
    '-r300' );              % resolution in dpi

export_fig( gcf, ...        % figure handle
    'demo_qualityfig_3',... % name of output file without extension
    '-painters', ...        % renderer
    '-tif', ...             % file format
    '-r300' );              % resolution in dpi

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Version 4: Adding parameters to control font sizes and linewidths etc.

% Fonts
FontName = 'Times';
FSsm = 7; % small font size
FSmed = 10; % medium font size

% Line widths
LWthin = 1; % thin lines

% Colors
col1 = [0,0,1];

% Axis position
left = 0.12;  % space on LHS of figure, normalised units
right = 0.02; % space on RHS of figure
top = 0.05;   % space above figure
bottom = 0.1; % space below figure
hspace = 0.07;% horizontal space between axes

height = (1-top-bottom); % height of axis
width = (1-left-right-hspace)/2; % width of axis

across = [hspace+width,0,0,0];
pos1 = [left,1-top-height,width,height]; % position of axis
pos2 = pos1+across;

figure

ax1 = axes('position',pos1); % produce axis replaces subplot(1,2,1)
plot(t,s1,'-','linewidth',LWthin)
ylabel('y','fontname',FontName,'FontSize',FSmed)
xlabel('\omega = 2 \pi c/\lambda','fontname',FontName,'FontSize',FSmed)
set(ax1,'FontName',FontName,'FontSize',FSsm)

ax2 = axes('position',pos2); % produce second axis replace subplot(1,2,2)
plot(t,s2,'-','linewidth',LWthin)
xlabel('\omega = 2 \pi c/\lambda','fontname',FontName,'FontSize',FSmed)
set(ax2,'FontName',FontName,'FontSize',FSsm)

PS = [14,10]; % paper size (in centimeters)
PP = [0,0,PS]; % paper position on the printed page (in centimeters)

set(gcf,'paperpositionmode','manual','paperposition', ...
        PP,'papersize',PS, 'paperunits','centimeters');

filename = 'demo_qualityfig_4.pdf';
print(gcf,'-dpdf',filename,'-painters','-loose'); % loose option stops matlab
						   % cropping white space
                                                   % automatically

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%
%  example loglog
%

x = linspace(-1,2);
loglog(x,exp(x),'-s');
grid on;

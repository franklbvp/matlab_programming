x1 = [0 1 1]; 
y1 = [0 0 1]; 
z1 = [0 0 0]; 

patch(x1, y1, z1,'r') % show patch in red enter

x2 = [0 1 0]; 
y2 = [0 1 1]; 
z2 = [0 0 1]; 

patch(x2, y2, z2, 'g') % show patch in green enter

view(3); grid % 3D view with grid enter
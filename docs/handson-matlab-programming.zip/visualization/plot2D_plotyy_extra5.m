%
% plot2D_plotyy
% based on
% http://www.rennes.telecom-bretagne.eu/~gbertran/pages/tutorials_matlab
% 
close all
clear
clc

% data definition
x=[0:0.1:50];
y1 = sin(x) .* exp(-x/5) + log(abs(x)+0.5) + rand(1,501);
y2 = 10 - log(x+1) + 2* cos(x).*rand(1,501);

% draw the plots
% use handles to change the appearance of the plots
[ax,h1,h2]=plotyy(x,y1,x,y2);

hold on
h3 = plot(x,log(x+1),'r^','MarkerSize',4)

% plot h3 uses left y axis
set(h3,'Parent',ax(1))
% labels and look of the curves
xlabel('Experiment number');
title('A quite complete example of multiple y-axes plot');
set(get(ax(1),'Ylabel'),'String','y1 and y3 [Mb/s]');
set(get(ax(2),'Ylabel'),'String','y2 [cm]');
set(h1,'Marker','o','LineStyle','none','MarkerEdgeColor','b','MarkerSize',6)
set(h2,'Marker','+','LineStyle','none','MarkerEdgeColor','k','MarkerSize',6)
handle= legend([h1,h2,h3],'y1= sin(x) .* exp(-x/5) + log(abs(x)+0.5) + rand(1,501)','y2 = 10 - log(x+1) + 2* cos(x).*rand(1,501)','log(x+1)');
set(handle,'Fontsize', 10);
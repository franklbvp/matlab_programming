%
% fill3
%
%
% FILL3  Filled 3-D polygons.
%    FILL3(X,Y,Z,C) fills the 3-D polygon defined by vectors X, Y and Z
%    with the color specified by C.  The vertices of the polygon
%    are specified by triples of components of X, Y and Z.  If necessary,
%    the polygon is closed by connecting the last vertex to the first.
% 
%    If C is a single character string chosen from the list 'r','g','b',
%    'c','m','y','w','k', or an RGB row vector triple, [r g b], the
%    polygon is filled with the constant specified color.
% 
%    If C is a vector the same length as X, Y and Z, its elements are
%    scaled by CAXIS and used as indices into the current COLORMAP to
%    specify colors at the vertices; the color within the polygon is
%    obtained by bilinear interpolation in the vertex colors.
 
close all
clear all

% generate data
x = rand(3,10);
y = rand(3,10);
z = rand(3,10);
c = rand(3,10);

fill3(x, y, z, c)

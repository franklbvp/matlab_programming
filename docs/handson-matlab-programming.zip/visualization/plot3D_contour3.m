%
% example contour3
%
[x, y, z] = peaks(100);
contour3(x,y,z, 30);

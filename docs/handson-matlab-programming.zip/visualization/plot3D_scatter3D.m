%
% 5D plot with scatter3
%   additional dimensions:
%       size
%       color
%
% generate some data
x = rand(1,100);
y = rand(1,100);
z = rand(1,100);
i = rand(1,100)*200;

% specify the indexed color for each point
icolor = ceil((i/max(i))*256);

% default visualization
hf1 = figure;
scatter3(x,y,z,i,icolor);

% filled spheres and colorbar
hf2 = figure;
hs3 = scatter3(x,y,z,i,icolor,'filled');
colormap(gray);
colorbar;

saveas(hs3, 'scat3','png');

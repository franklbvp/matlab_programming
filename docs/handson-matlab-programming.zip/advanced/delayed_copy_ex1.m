function b = delayed_copy_ex1(A)
b = 10*A(1,1);
end
%
% timing double versus integer
%
% A: default dounble precision
A=zeros(10000);
tic
A=A+100;
toc
% B: int8
B=int8(zeros(10000));
tic
B=B+100;
toc


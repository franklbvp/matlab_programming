%% A Markup Example
% This file is an example on how to use the markup tools.
% Use the different Markup elements from the Menu
%
% - this section is the 'Document Title and Introduction'

%% SECTION TITLE 1
% this is a new section 

%%
% this is a bulleted list
% * ITEM1
% * ITEM2
% 

y = sin(1:10);
plot(y)

% DEMO
%
% Files
%   demo_publish_sine_wave - PLot Sine Wave

function GenerateProfile(functor, path)
% http://my.opera.com/quantumman/blog/profile-in-matlab-3
% In addition, if on UNIX/LINUX system, the file $matlab/toolbox/local/docopt.m should be altered at line 52, where your default web browser is filled in:
% doccmd = 'firefox';

  profile on;
  functor;
  profile_data = profile('info');
  profsave(profile_data, path);
  profile off;
end

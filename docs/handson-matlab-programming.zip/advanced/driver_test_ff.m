%% script function calling test_ff
%
% this is the driver function
x = 1 : 10;
z = test_ff(x)
plot(x, z)
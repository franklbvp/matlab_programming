%
% timing_ex_2.m
%
% measure the time needed to solve a linear system
%
% tic starts the timer.
% toc shows the time elapsed since tic

for n = 1:200
    A = rand(n,n);
    b = rand(n,1);
    tic
    x = A\b;
    t(n) = toc;
end
plot(t)


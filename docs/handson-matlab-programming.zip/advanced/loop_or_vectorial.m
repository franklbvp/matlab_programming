function [t_loop_row, t_loop_col, t_loop_vec] = loop_or_vectorial(dimArray)
% vectorial or loop
%
% adding 2 arrays
% check the timing
%
% Result
%  t_loop_row: time spent for loop row-by-row
%  t_loop_col: time spent for loop column-by-column
%  t_loop_vec: time spent vectorial (no loop)
%
A = rand(dimArray)*10;
B = rand(dimArray)*10;

% row by row
tic
for ir = 1:dimArray
    for ic = 1:dimArray
        C(ir, ic) = A(ir, ic) + B(ir, ic);
    end
end
toc
t_loop_row = toc;

% column by column
tic
for ic = 1:dimArray
    for ir = 1:dimArray
        C(ir, ic) = A(ir, ic) + B(ir, ic);
    end
end
toc
t_loop_col = toc;

% vectorial
tic
C = A + B;
toc
t_loop_vec = toc;

end


%
% Mandelbrot 
% http://www.students.tut.fi/~warp/MandScripts/matlab.html
%
%
xmax=2;
steps=200;
maxiter=32;
%
% preallocate the matrix
%
% Z=0;
%
Z = zeros(steps);
x=[-xmax:2*xmax/(steps-1):xmax];
y=[-xmax:2*xmax/(steps-1):xmax];
[X Y] = meshgrid(x,y);

%
% define i
%
i = sqrt(-1);
%
for m=1:steps
  for n=1:steps
    c=-xmax+2*xmax*n/steps-.5 + i*(-xmax+2*xmax*m/steps);
    z=c;
    % 
    % r is used as a loop-counter, but is also used in a calculation below
    % the loop
    %
    rmax = maxiter;
    for r=0:maxiter
      z=z*z+c;
      if abs(z)>2 
          rmax=r;
          break
      end
    end
    Z(m,n)=sqrt(rmax/maxiter);
  end
end

figure; imagesc(Z);
figure; mesh(X,Y,Z)
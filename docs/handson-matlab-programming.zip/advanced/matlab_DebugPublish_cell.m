%% Publishing Demo
%
%% A short show case
% 
% a bulleted list
%
% * ITEM1
% * ITEM2
% 
%
% some _ITALIC TEXT_ in the *document*
% <http://www.mathworks.com MathWorks>

%% Preformatted
% 
%  PREFORMATTED
%  TEXT
% 
%% MATLAB(R) Code
% 
%   for i = 1:10
%       disp x
%   end
% 
%% SECTION TITLE
% DESCRIPTIVE TEXT
% 
% * ITEM1
% * _ITEM2_
% 
%
% <http://www.mathworks.com MathWorks>


%%
% use the standard Matlab function imread

street1=imread('street1.jpg'); 
street2=imread('street2.jpg');


%% Display first image
% use the standard matlab function image to display the image
cla;
image(street1); % Display image
axis equal; axis off

%% Display second image
image(street2); % Display image
axis equal; axis off

%% Scale image with a double constant but create an integer
duller = 0.7 * street2;
image(duller); % Display image
axis equal; axis off

%% Scale an image  
subplot(1,2,1);
image(street2);
axis off equal tight
title('Original');  % Display image

subplot(1,2,2);
image(duller);
axis off equal tight
title('Duller');    % Display image

%% Add an image
combined = street1 + duller; % Add |uint8| images
subplot(1,1,1)
cla;
image(combined); % Display image
title('Combined');
axis equal; axis off

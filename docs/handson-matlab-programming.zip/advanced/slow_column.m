% slow_column.m
%A=zeros(10000);
tic
%[xs ys] = size(A);
for j=1:ys
   for i=1:xs
      A(i,j)=A(i,j)+100;
   end
end
toc
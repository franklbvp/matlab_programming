%
% Purpose: test if there is a difference in performance using different
% data types
%
% source: Scott Merell Gorlin - advanced Matlab course MIT
%



N = 100000;

d(1) = 0;
c{1} = 0;

tic
for i = 1:N
    d(1) = i;
end
DoubleTime = toc

% Cell array
tic
for i = 1:N
    c{1} = i;
end
CellTime = toc

Speedup = CellTime / DoubleTime
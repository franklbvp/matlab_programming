% slow_row.m
A=zeros(10000);
tic
[xs ys] = size(A);
for i=1:xs
   for j=1:ys
      A(i,j)=A(i,j)+100;
   end
end
toc
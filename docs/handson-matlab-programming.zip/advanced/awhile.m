%
% purpose: demo profiler
% source http://blogs.mathworks.com/desktop/2010/02/01/speeding-up-your-program-through-profiling/
%  TODO  still no comments
function z = awhile
    for i=100:100:500
        x = rand(i);
        y = rand(i);
        z = calculate(x,y);
    end
function z = calculate(x,y)
    z = conv2(x,y);
    pause(3);
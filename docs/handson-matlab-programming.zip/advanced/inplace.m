%
% in place or not?
%
x = rand(5000);
tic
%y  = x.^2;
x  = x.^2;
toc
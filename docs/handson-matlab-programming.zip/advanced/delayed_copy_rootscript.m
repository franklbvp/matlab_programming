%
% showing effect of delayed copy: When MATLAB arrays passed to a function, 
% only copied to localworkspace when it is modified
% 

clear
clc

A = rand(10000);

tic; b=delayed_copy_ex1(A); toc

tic; b=delayed_copy_ex2(A); toc
% fast.m
A=zeros(10000);
tic
A=A+100;
toc
%
% example allocation
%
% TODO: nothing - just a test
%
tic;
x = [3 5; 8 7];
%
% verify with y allocated or not
% 
% y = zeros(1,300000);
for i=1:3000
    y(i)=det(x^i);
end
toc
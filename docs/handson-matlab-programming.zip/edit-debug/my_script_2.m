%
% my_script_2
%
% use veriable a and b to calculate the product
%
prodab = a * b;
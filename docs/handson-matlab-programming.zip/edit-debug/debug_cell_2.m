%% put some data in workspace

clear
close all
clc

% variables a and b

a = 4.5;
b = 1:10;

%% Display plot
% use the standard matlab plot function
figure
y = a*cos(b);
plot(b,y);

%
% debug script
%

% put a breakpoint at the beginning of the script
%
clear

% step through the code
%
a = 10;
b = 20;
c = a + b;
d = 5 + a + b / a;


% step through the code with F10 (step)
my_script_1;


% step into the code with F11 (step in)
my_script_2;


% loop
for i = 1:100
    disp(i)
    i2 = i-2 * i * i
end

%%
% a section
% logical division in m-file
x = 1:100;
y = sin(x);

%
% my_script_1
%
% use veriable a and b to calculate the sum
%
sumab = a + b;
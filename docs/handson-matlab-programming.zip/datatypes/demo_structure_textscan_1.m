%% Import data from text file.
% Script for importing data from the following text file:
%
%    I:\Cursus_Final\Matlab\Matlab_Modules\DataTypes\demo\mixed_data.dat
%
% 
%% Initialize variables.
%filename = 'I:\Cursus_Final\Matlab\Matlab_Modules\DataTypes\demo\mixed_data.dat';
filename = 'mixed_data.dat';
delimiter = ',';

%% Read columns of data as text:
% For more information, see the TEXTSCAN documentation.
formatSpec = '%d %f %s %c %d';

%% Open the text file.
fileID = fopen(filename,'r');

%% Read columns of data according to the format.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'TextType', 'string',  'ReturnOnError', false);

%% Close the text file.
fclose(fileID);

%% Show contents of dataArray
dataArray(1)
dataArray(2)
dataArray(3)
dataArray(4)
dataArray(5)

celldisp(dataArray);
cellplot(dataArray);

%% Extract the data in columns and convert if needed
nr_index = double(dataArray{1});
scoreA = dataArray{2};
names = dataArray{3};
code = dataArray{4};
scoreB = dataArray{5};

fields = {'nr_index', 'scoreA', 'names', 'code', 'scoreB'};
compounds = cell2struct(dataArray, fields, 2);  % specify the dimension along to create the structure 

%% do some analysis
max_scoreA = max(compounds.scoreA);
fprintf('maximum scoreA = %f \n', max_scoreA);
max_scoreB = max(compounds.scoreB);
fprintf('maximum scoreB = %d \n', max_scoreB);

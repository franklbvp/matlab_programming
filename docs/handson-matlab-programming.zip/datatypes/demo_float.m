%
% demo_float.m
%
% showing some features of floating point
%
clear
%
realmax('double')
realmin('double')
eps('double')
%
realmax('single')
realmin('single')
eps('single')
%
m = zeros(2,6, 'single')
class(m)
whos
%
% explicit casting using the cast function
k = 1:7
class(k)
kk = single(k)
class(kk)
kkk = cast(k, 'single')
class(kkk)

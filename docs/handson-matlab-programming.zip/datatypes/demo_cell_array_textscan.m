%
% http://matlab.cheme.cmu.edu/category/file-io/
%

% open file and read data
fid = fopen('antoine_data.dat');
C = textscan(fid,'%d%s%s%f%f%f%f%f%s%s','headerlines',7);
fclose(fid);

% convert the cell array output of textscan into variables
[id formula compound A B C Tmin Tmax i j] = C{:};


% take element 362
A362 = A(362);
B362 = B(362);
C362 = C(362);
Tmin362 = Tmin(362);
Tmax362 = Tmax(362);


% plot vapor pressure of element 362 over the allowable temperature range.

T = linspace(Tmin362, Tmax362);
P = 10.^(A362 - B362./(T+C362));
plot(T,P)
xlabel('T (\circC)')
ylabel('P_{vap} (mmHg)')
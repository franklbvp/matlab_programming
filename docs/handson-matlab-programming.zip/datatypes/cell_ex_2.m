%
% another demo on cell arrays
%

a = [1, 2, 3, 4, 5];     % a is a vector
b = ' Hello world';      % b is a string
c = [10, 11, 12; 13, 14, 15; 16, 17, 18];    % c is a 3*3 matrix

d = {a, b, c};             % d is a cell array holding a, b and c


d{1}    % shows the content of the first element in cell array
        % content addressing

d(1)    % shows that it points to a vector 
        % 
d{2}

d(2)

d{3}

d(3)

a = a + 5; % manipulate the vector a, verify if it also changes d{1}

a

d{1}   % is it still the same as a?

d{1} + 5   % is this allowed?

d(1) + 5   % is this allowed?


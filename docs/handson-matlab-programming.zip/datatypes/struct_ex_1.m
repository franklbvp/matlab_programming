%
% structure example
%
student = struct('name', {}, 'street', {},'city',{}, 'zip',{})
student
%
student = struct('name', {'Leo Poels'}, 'street', {'Lei'},'city',{'Leuven'}, 'zip',{3000})
%
student(2).name  = 'John Doe';
student(2).street = 'de Croylaan 52';
student(2).city = 'Heverlee';
student(2).zip = 3001;
student(3).name  = 'John Deo';
student(3).street = 'de Croylaan 54';
student(3).city = 'Heverlee';
student(3).zip = 3001;
%
% test function
%
student = setfield(student,{2},'name','John Denver')
student(2).name
%
x1 = rand(1,4);
x2 = rand(1,4);

y_l = x1 < x2
class(y_l)

% make selections

x = [1.2 0  -9]
xf = [1 0 1]

xl = logical(x)
y = rand(1,3)
y(xl)
y(xf)

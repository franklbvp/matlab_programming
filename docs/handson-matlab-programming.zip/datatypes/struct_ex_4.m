%
% based on http://matlab.cheme.cmu.edu/category/file-io/
%

% open file and read data
fid = fopen('antoine_data.dat');
C = textscan(fid,'%d%s%s%f%f%f%f%f%s%s','headerlines',7);
fclose(fid);

% convert the cell array output of textscan into variables
[id formula compound AA AB AC Tmin Tmax i j] = C{:};

% convert the cell array into a structure of arrays
rowHeadings = {'id', 'formula', 'compound', 'A', 'B', 'C', ...
   'Tmin', 'Tmax', 'i', 'j'};
compounds = cell2struct(C, rowHeadings, 2);

% convert structure of arrays into array of structures (matlabcentral code)
Acompounds = structofarrays2arrayofstructs(compounds)


% plot vapor pressure of component 362 over the allowable temperature range.

T = linspace(Acompounds(362).Tmin, Acompounds(362).Tmax);
P = 10.^(Acompounds(362).A - Acompounds(362).B./(T+Acompounds(362).C));
plot(T,P)
xlabel('T (\circC)')
ylabel('P_{vap} (mmHg)')
%
% example construction cell array
%
nc = 4;
cnms = char('ammonia', 'nitrogen',  'hydrogen', 'argon');
%
% S = char(t1,t2,t3,..) forms the character array S containing the text
% strings T1,T2,T3,... as rows
%
mw = [17.0300,    28.0130,     2.0160,    39.9480];
Aabc = [15.494    13.45    12.78;
  13.915  2363.20   658.22;
 232.320   832.78   -22.62;
  -2.854     8.08     2.36]

%
% allocate an empty cell, with 4 containers
celldat=cell(1, 4)

%
% fill the cells
celldat{1,1}=nc;
celldat{1,2}=cnms;
celldat{1,3}=mw;
celldat{1,4}=Aabc;

%
% visualisation of the cell
celldat
celldisp(celldat)
cellplot(celldat)

%
% use cell elements
mwx = celldat{1,3}(2)
ant22 = celldat{1,4}(2,2)
celldat{2}(1, :)

%
% work the other way round and use the deal function

[nc_d  cnms_d  mw_d  Aabc_d] = deal(celldat{:});

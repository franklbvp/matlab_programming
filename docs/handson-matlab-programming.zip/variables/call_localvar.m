%
% call_localvar
%
global P
localvar

P = 10;
localvar

fprintf('In call_localvar, the value of P is: %d\n', P);
fprintf('In call_localvar, the value of P1 is: %d\n', P1);
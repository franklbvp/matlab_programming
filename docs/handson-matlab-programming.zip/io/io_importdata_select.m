%%
% voorbeeld inlezen van een bestand met 1 header line (text) en numerieke
% data in de kolommen
%
% voorbeeld bestand: 82_header.dat
%
% gebruik de functie importdata, het resultaat van deze functie wordt
% schrijft alle gegevens weg in een structure (met als fieldnames: data,
% textdata, colheaders
%
% A.colheaders bevat de headers
% A.data bevat de numerieke gegevens
%
A = importdata('82_header.dat');

%%
% zoek de positie van een bepaalde kolom
% dit kan via een combinatie van find en ismember
% 
% zoek bv. de positie van de kolom met header XTRA
%  - neem colheaders veld van de ingelezen data (A.colheaders)
%  - ga na of 'XTRA' in de lijst voorkomt, doe dit via ismember (de string
%       die je opgeeft is degene waarnaar je op zoek bent
%  - zoek de positie van de kolom via find
%  
poscol = find(ismember(A.colheaders, 'XTRA'));

%%
% selecteer alle gevens van de kolom in kwestie
data_ok = A.data(:,poscol);

%%
% plot
plot(data_ok);


%
% example code using fscanf - fgets
% http://cse.unl.edu/~sincovec/Matlab/Lesson%2024/CS211%20Lesson%2024%20-%20Text%20File%20Input-Output.htm
%
clear; clc;
Input_file_id = fopen('test_fscanf_fgets.txt',  'r');

Line = fgets(Input_file_id);                   % read the label line
Vector = fscanf(Input_file_id, '%f', [1 5] );
Line = fgets(Input_file_id);                   % get to the next line of the file
Line = fgets(Input_file_id);                   % read the label line
Matrix = fscanf(Input_file_id, '%f', [2 3] );  % reads in column major order: column by column
Matrix = Matrix';                              % transpose the matrix to match the view in the file
fclose(Input_file_id );
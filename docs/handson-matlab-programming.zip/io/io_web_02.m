%
% MathWorks example webread
%

% image
url = 'http://heritage.stsci.edu/2007/14/images/p0714aa.jpg';
rgb = webread(url);
imshow(rgb)

% Read temperature data for the USA from the World Bank Climate Data API. 
% Plot temperatures from the years 1901�2012.
% Read data from the World Bank. This API returns data as a JSON object.

api = 'http://climatedataapi.worldbank.org/climateweb/rest/v1/';
url = [api 'country/cru/tas/year/USA'];
S = webread(url)
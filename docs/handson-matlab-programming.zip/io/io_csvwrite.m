%
% csvwrite demo - write a file testfile .csv
%
csvwrite('testfile_00.csv', [1,2;3,4], 0 ,0)

csvwrite('testfile_32.csv', [1,2;3,4], 3 ,2)

%
% writing multiple files with dlmwrite
%

for k = 1:5
    filename=['file_', num2str(k),'.tst']

    for i=0.1:0.1:1

        for j=1:1:10
            ligne=['X,REAL,',num2str(i)];
%            dlmwrite(filename, [ligne],'');   % dlmwrite without append will overwrite existing data!
            dlmwrite(filename, [ligne],'-append','delimiter','');

            ligne=['Y,REAL,',num2str(j)];
            dlmwrite(filename, [ligne],'-append','delimiter','');

            ligne='R,REAL,0.055';
            dlmwrite(filename, [ligne],'-append','delimiter','');

            ligne='NUM,REAL,0';
            dlmwrite(filename, [ligne],'-append','delimiter','');
        end
    end 
end
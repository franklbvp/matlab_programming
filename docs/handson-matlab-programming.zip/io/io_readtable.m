%
% readtable - available from 2013b
% Read column-oriented delimited numbers or a mix of strings and numbers
%
T = readtable('my_csv_table.dat')
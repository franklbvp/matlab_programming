clear
clc

block = urlread('http://manyeyes.alphaworks.ibm.com/manyeyes/datasets/us-zipcodes-with-city-state-fips-lat/versions/1.txt');

%%
readData = textscan(block, '%n %n %s %s %n %n %n %n', 'delimiter', char(9));

statenum = readData{1};
zip = readData{2};
abrev = readData{3};
city = readData{4};
lat = readData{5};
lon = readData{6};
pop = readData{7};
percent = readData{8};

clear readData

%%

load usapolygon

%%
vi = (pop > 53130.23903);

plot(uslon, uslat, -lat(vi), lon(vi), '.')

%%
city{vi}
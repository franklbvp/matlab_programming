%
% test some of the properties of the textscan function
%
clear
clc

fid = fopen('grades.dat', 'r');
grades = textscan(fid, '%f %f %f', 3, 'headerlines', 1);
%
% convert the cell array to an array
%
Ar_grades = cell2mat(grades);

fclose(fid);
%
%  read mobile_test.dat, the file structure:
%
%    * Two headerlines of description
%    * A parameter m
%    * A m * p table of data
%
% C = textscan(fid, 'format', N)  reads data from the file, reusing the
%                                 format conversion specifier N times
%

fid = fopen('mobile_test.dat', 'r'); % Open text file
InputText = textscan(fid, '%s', 2, 'delimiter', '\n'); % Read header lines
HeaderLines = InputText{1};

%
% C = textscan(fid, 'format')  reads data from an open text file identified
%                              by file identifier fid into cell array C
%
InputText = textscan(fid, 'Num tests=%f'); % Read parameter value
NumRows=InputText{1};
%
InputText=textscan(fid, '%f', 'delimiter', ','); % Read data block
%
% use reshape to change the format ??? inversion of rows & columns?
%
Data=reshape(InputText{1},[],NumRows)';
Data
%
% read second part
% 
InputText = textscan(fid, '%s', 2, 'delimiter', '\n'); % Read header lines
InputText = textscan(fid, 'Num tests=%f'); % Read parameter value
NumRows=InputText{1};
InputText=textscan(fid, '%f', 'delimiter', ','); % Read data block
Data2=reshape(InputText{1},[],NumRows)';
Data2

fclose(fid);

%
% read the file sales.txt
%
fid = fopen('sales.txt', 'r');
InputSales = textscan(fid, '%n %s %s %n %f');
%
% seek the beginning of the file
%
fseek(fid, 0, -1);
%
% skip some fields by putting a * next to %
%
InputSales2 = textscan(fid, '%n %*s %*s %n %f');
Ar_InputSales2 = cell2mat(InputSales2);
fclose(fid);
%
%
% io_inputdlg
%
% example of a predefined gui
%
global R
R=0.0821; 

% Example Program for use of Dialog Boxes
% Define a title for the dialog box
box_title = 'Data Entry for Ideal Gas Law Problem';

% Define the labels for the individual entries
entries = { 'Temperature_1 (K)', 'Temperature_2 (K)'};

% Create the dialog box with the inputdlg command
z = inputdlg(entries, box_title);

% Convert the entries. Numerical data is converted by using the curly
% brackets to access the cell contents, and using the 'str2num' command
% to convert the string to a number. To convert the filename only use the
% curly brackets. Note: these are not parenthesis.
temp1 = str2num(z{1});
temp2 = str2num(z{2});


v=10:.5:30; 

p200 = func_ideal_gas(temp1, v); 
p300 = func_ideal_gas(temp2, v); 

plot(v,p200,'r-',v,p300,'g:') 
legend('temp1','temp2') 
xlabel('Volume (l)') 
ylabel('Pressure (atm)') 


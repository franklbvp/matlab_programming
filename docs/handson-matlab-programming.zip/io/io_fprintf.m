%
% fprintf example
%
s = [101; 105; 107; 109];

m = [1 12 101.6; 5 7.3 124.87; 3 40 154.8; 7 1 70.4];


fp = fopen('subdata.dat', 'w');
fprintf(fp, 'SubNum\tCol1\tCol2\tCol3\n');
fprintf(fp, '%d\t%d\t%f\t%.2f\n', s(1), m(1,1 :3));
fprintf(fp, '%d\t%d\t%f\t%.2f\n', s(2), m(2,1 :3));
fprintf(fp, '%d\t%d\t%f\t%.2f\n', s(3), m(3,1 :3));
fprintf(fp, '%d\t%d\t%f\t%.2f\n', s(4), m(4,1), m(4, 2), m(4,3));
fclose(fp);

fp = fopen('subdata2.dat', 'w');
fprintf(fp, 'SubNum\tCol1\tCol2\tCol3\n');
fprintf(fp, '%d\t%d\t%f\t%.2f\n', s, m);
fclose(fp);

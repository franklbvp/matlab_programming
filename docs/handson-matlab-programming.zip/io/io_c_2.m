%
% read binary data
%

fid=fopen('temp1.bin','r');	% open temp1.bin  "read binary"

b=fread(fid,[101,2],'float');	% read data in "b"

fclose(fid);                 	% close file

plot(b(:,1),b(:,2))             % plot 

%
% dlmread demo - read a file data.csv
%
%
dat = dlmread('data2.csv', ',' );
%
% plot the data
%
 plot (dat(:,1), dat(:,2));

range = [0 0 15 1]
datm = dlmread('data2.csv', ',', range);

%
% try to read a mixed (text + numerics) data file outage.csv
 
% outage_dat = dlmread('outages.csv', ',');

%

